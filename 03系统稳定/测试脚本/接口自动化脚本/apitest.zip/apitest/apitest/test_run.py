#!/usr/bin/env python
# coding: utf-8
import unittest
import sys
import imp
import os
import types

test_class_list = ['compute.auth_api.AuthTest','compute.compute_api.ComputeApiTest','compute.shutdownInstance_api.ShutdownInstanceTest','compute.describeInstances_api.DescribeInstancesTest','compute.describeSecurityGroups_api.DescribeSecurityGroupsTest',
                   'compute.operationLog_api.OperationLogTest','compute.startInstance_api.StartInstanceTest','compute.rebootInstance_api.RebootInstanceTest','compute.deleteInstance_api.DeleteInstanceTest',
                  'compute.resizeInstance_api.ResizeInstanceTest','compute.resizeInstance_api.ResizeInstanceTest','compute.modifyInstance_api.ModifyInstanceTest','compute.modifyInstanceSubnet_api.ModifyInstanceSubnetTest',
                   'compute.instanceAndSecurityGroup.InstanceAndSecurityGroupTest']
"""test_class_list = ['compute.auth_api.AuthTest','compute.compute_api.ComputeApiTest','compute.resizeInstance_api.ResizeInstanceTest','compute.operationLog_api.OperationLogTest','compute.describeInstances_api.DescribeInstancesTest']
"""
if __name__ == "__main__":
    project_dir = os.path.dirname(__file__)
    programs = None
    if len(sys.argv) > 1:
        programs = sys.argv[1:]
    suite = unittest.TestSuite()
    if programs:
        for program in programs:
            #suite.addTest(compute_api.ComputeApiTest(program))
            param_dict = program.split('.')
            i = 0
            pre_module = None
            current_module = None
            while True:
                module_name = param_dict[i]
                test_module = imp.load_module(module_name,
                                              *imp.find_module(module_name,
                                                               pre_module.__path__ if pre_module else [project_dir]))
                class_name = param_dict[i + 1]
                if hasattr(test_module, class_name):
                    class_instance = getattr(test_module, class_name)
                    if isinstance(class_instance, types.TypeType):
                        if len(param_dict) > i + 2:
                            suite.addTest(class_instance(param_dict[i+2]))
                        else:
                            suite.addTest(unittest.makeSuite(class_instance))
                        break
                pre_module = test_module
                i += 1
    else:
        for test_class in test_class_list:
            test_class_dict = test_class.split('.')
            module_name = test_class_dict[-2]
            class_name = test_class_dict[-1]
            path_dict = test_class_dict[0:len(test_class_dict) - 2]
            path_dict[0:0] = [project_dir]
            test_module = imp.load_module(module_name,
                                         *imp.find_module(module_name, ['/'.join(path_dict)]))
            suite.addTest(unittest.makeSuite(getattr(test_module, class_name)))
    runner = unittest.TextTestRunner()
    runner.run(suite)
# if __name__ == "__main__":
#     programs = None
#     # sys.argv 是存放系统的参数，包括脚本名本身
#     if len(sys.argv) > 1:
#         # sys.argv[1:]是读取第一个元素后的值，不包含第一个元素
#         programs = sys.argv[1:]
#     # 构造测试集
#     suite = unittest.TestSuite()
#     if programs:
#         for program in programs:
#             suite.addTest(compute_api.ComputeApiTest(program))
#             suite.addTest(shutdownInstance_api.ShutdownInstanceTest(program))
#     else:
#         suite.addTest(unittest.makeSuite(compute_api.ComputeApiTest))
#     # 运行测试集
#     runner = unittest.TextTestRunner()
#     runner.run(suite)

