#!/usr/bin/env python
# coding: utf-8

from config import Config
from utils import auth, request_utils
import unittest

class DescribeSecurityGroupsTest(unittest.TestCase):

    #按照条件查询(SearchWord为空)
    def testDescribeSecurityGroups(self):
        print "testDescribeSecurityGroups"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeSecurityGroups"
        param["SecurityGroupIds"] = Config.get_options("describeSecurityGroups", "default_group_ids").split(",")
        searchWord =  Config.get_options("describeSecurityGroups", "default_searchword")
        param["SearchWord"] =request_utils.none_and_null(searchWord)
        param["Offset"] = Config.get_options("describeSecurityGroups", "default_offset")
        param["Limit"] = Config.get_options("describeSecurityGroups", "default_limit")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        # 判断是是否是成功
        if result["data"]["Code"] == "110068":
            print "run ok!"
        self.assertEquals(result["status_code"], 200)

    #searchWord格式错误
    def testGroupsSearchWordFormat(self):
        print "testGroupsSearchWordFormat"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeSecurityGroups"
        param["SecurityGroupIds"] = Config.get_options("describeSecurityGroups", "default_group_ids").split(
            ",")
        searchWord = Config.get_options("describeInstances", "searchword_format_error")
        if ('null' == searchWord):
            searchWord = ''
        param["SearchWord"] = searchWord
        param["Offset"] = Config.get_options("describeSecurityGroups", "default_offset")
        param["Limit"] = Config.get_options("describeSecurityGroups", "default_limit")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100023")
        self.assertEquals(result["status_code"], 200)

    # searchWord模糊查询
    def testGroupsSearchWordLike(self):
        print "testGroupsSearchWordLike"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeSecurityGroups"
        searchWord = Config.get_options("describeSecurityGroups", "searchword_like")
        param["SearchWord"] = request_utils.none_and_null(searchWord)
        param["Offset"] = Config.get_options("describeSecurityGroups", "default_offset")
        param["Limit"] = Config.get_options("describeSecurityGroups", "default_limit")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # searchWord未设置
    def testGroupsSearchWordNotSet(self):
        print "testGroupsSearchWordNotSet"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeSecurityGroups"
        param["Offset"] = Config.get_options("describeSecurityGroups", "default_offset")
        param["Limit"] = Config.get_options("describeSecurityGroups", "default_limit")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 偏移量不合法
    def testGroupsOffsetFormatError(self):
        print "testGroupsOffsetFormatError"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeSecurityGroups"
        param["Offset"] = Config.get_options("describeInstances", "offset_format_error")
        param["Limit"] = Config.get_options("describeSecurityGroups", "default_limit")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100026")
        self.assertEquals(result["status_code"], 200)

    # limit 不合法
    def testGroupsLimitFormatError(self):
        print "testGroupsLimitFormatError"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeSecurityGroups"
        param["Offset"] = Config.get_options("describeSecurityGroups", "default_offset")
        param["Limit"] = Config.get_options("describeInstances", "limit_fromat_error")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100027")
        self.assertEquals(result["status_code"], 200)

    # 所有的参数有默认值的
    def testGroupsDefaultInfo(self):
        print "testGroupsDefaultInfo"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeSecurityGroups"
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 所有的参数都为空
    def testGroupsIsNull(self):
        print "testGroupsIsNull"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeSecurityGroups"
        param["SecurityGroupIds"] = []
        param["SearchWord"] = ''
        param["Offset"] = ''
        param["Limit"] = '30'
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # SecurityGroupIds不存在
    def testGroupsSecurityGroupIdsNotExit(self):
        print "testGroupsSecurityGroupIdsNotExit"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeSecurityGroups"
        param["SecurityGroupIds"] = Config.get_options("describeSecurityGroups", "group_ids_notexit").split(",")
        param["SearchWord"] = ''
        param["Offset"] = ''
        param["Limit"] = ''
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110065")
        self.assertEquals(result["status_code"], 200)

    # SecurityGroupIds格式不正确
    def testSecurityGroupIdsFormatError(self):
        print "testSecurityGroupIdsFormatError"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeSecurityGroups"
        param["SecurityGroupIds"] = Config.get_options("describeSecurityGroups", "group_ids_error").split(",")
        param["SearchWord"] = ''
        param["Offset"] = ''
        param["Limit"] = ''
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110066")
        self.assertEquals(result["status_code"], 200)

    # SecurityGroupIds20个，如果20个的id有重复的只展示不重复的id
    def testSecurityGroupIds20(self):
        print "testSecurityGroupIds20"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeSecurityGroups"
        param["SecurityGroupIds"] = Config.get_options("describeSecurityGroups","securitygroup_ids_many").split(",")
        param["SearchWord"] = ''
        param["Offset"] = ''
        param["Limit"] = ''
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # SecurityGroupIds21个
    def testSecurityGroupIds21(self):
        print "testSecurityGroupIds21"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeSecurityGroups"
        param["SecurityGroupIds"] = Config.get_options("describeSecurityGroups",
                                                          "securitygroup_ids_many_21").split(",")
        param["SearchWord"] = ''
        param["Offset"] = ''
        param["Limit"] = ''
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110066")
        self.assertEquals(result["status_code"], 200)

    # 未找到相关查询结果
    def testSecurityGroupNotResult(self):
        print "testSecurityGroupNotResult"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeSecurityGroups"
        param["SecurityGroupIds"] = Config.get_options("describeSecurityGroups",
                                                          "securitygroup_ids_noresult").split(",")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        #param["Region"] = "beijing03"
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100025")
        self.assertEquals(result["status_code"], 200)

    # limit小于实际的条数
    def testSecurityGroupLimitSmall(self):
        print "testSecurityGroupLimitSmall"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeSecurityGroups"
        param["Limit"] = Config.get_options("describeSecurityGroups","limit_small")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

