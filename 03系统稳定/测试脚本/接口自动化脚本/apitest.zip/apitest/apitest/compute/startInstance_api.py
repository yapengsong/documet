#!/usr/bin/env python
# coding: utf-8

from config import Config
from utils import auth, request_utils
import unittest

class StartInstanceTest(unittest.TestCase):

  #关闭一个instanceid不存在的云主机
   def testStartInstance(self):
        print "testStartInstance"
        # 拼接数据
        param = {}
        param["Action"] = "StartInstance"
        param["InstanceId"] = Config.get_options("startInstance", "default_instanceid")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110043")
        self.assertEquals(result["status_code"], 200)

   #未设置instanceid
   def testStartInstanceNotSetID(self):
        print "testStartInstanceNotSetID"
        # 拼接数据
        param = {}
        param["Action"] = "StartInstance"
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110042")
        self.assertEquals(result["status_code"], 200)

   #设置instanceid,但是instanceid为空
   def testStartInstanceIDIsNull(self):
        print "testStartInstanceIDIsNull"
        # 拼接数据
        param = {}
        param["Action"] = "StartInstance"
        instanceId = Config.get_options("startInstance", "instanceid_null")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110042")
        self.assertEquals(result["status_code"], 200)

   #设置instanceid,但是instanceid格式错误
   def testStartInstanceIDFormatError(self):
        print "testStartInstanceIDFormatError"
        # 拼接数据
        param = {}
        param["Action"] = "StartInstance"
        instanceId = Config.get_options("startInstance", "instanceid_format_error")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110044")
        self.assertEquals(result["status_code"], 200)

   #设置instanceid,云主机为关闭状态
   def testStartInstanceShutOff(self):
        print "testStartInstanceShutOff"
        # 拼接数据
        param = {}
        param["Action"] = "StartInstance"
        instanceId = Config.get_options("startInstance", "instanceid_shutoff")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110048")
        self.assertEquals(result["status_code"], 200)

   # 云主机正在创建自定义镜像
   def testStartInstanceCreateImage(self):
        print "testStartInstanceCreateImage"
        # 拼接数据
        param = {}
        param["Action"] = "StartInstance"
        instanceId = Config.get_options("startInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110049")
        self.assertEquals(result["status_code"], 200)

   # 云主机故障
   def testStartInstanceError(self):
        print "testStartInstanceError"
        # 拼接数据
        param = {}
        param["Action"] = "StartInstance"
        instanceId = Config.get_options("startInstance", "instanceid_error")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110048")
        self.assertEquals(result["status_code"], 200)

  # 云主机已到期
   def testStartInstanceExpired(self):
        print "testStartInstanceExpired"
        # 拼接数据
        param = {}
        param["Action"] = "StartInstance"
        instanceId = Config.get_options("startInstance", "instanceid_expired")
        param["InstanceId"] =request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100019")
        self.assertEquals(result["status_code"], 200)

   # 云主机余额不足
   def testStartInstanceNotEnough(self):
        print "testStartInstanceNotEnough"
        # 拼接数据
        param = {}
        param["Action"] = "StartInstance"
        instanceId = Config.get_options("startInstance", "instanceid_not_enough")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100017")
        self.assertEquals(result["status_code"], 200)

   # 云主机必须为关机状态
   def testStartInstanceIsShutOff(self):
        print "testStartInstanceIsShutOff"
        # 拼接数据
        param = {}
        param["Action"] = "StartInstance"
        instanceId = Config.get_options("startInstance", "instance_not_start")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110056")
        self.assertEquals(result["status_code"], 200)