#!/usr/bin/env python
# coding: utf-8

from config import Config
from utils import auth, request_utils
import unittest
import time

class OperationLogTest(unittest.TestCase):

    # 查询日志操作(关键字格式错误)
    def testOperationLogSearchWordFE(self):
        print "testOperationLogSearchWordFE"
        # 拼接数据
        param = {}
        param["Action"] = "OperationLog"
        jobs = Config.get_options("operationLog", "default_jobs").split(',')
        param["Jobs"] = request_utils.array_filter_null(jobs)
        param["SearchWord"] = Config.get_options("operationLog", "searchword_format_error")
        param["Offset"] = Config.get_options("operationLog", "default_offset")
        param["Limit"] = Config.get_options("operationLog", "default_limit")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100023")
        self.assertEquals(result["status_code"], 200)

    # 查询日志操作（正确模糊查询）
    def testOperationLogDefault(self):
        print "testOperationLogDefault"
        # 拼接数据
        param = {}
        param["Action"] = "OperationLog"
        jobs = Config.get_options("operationLog", "default_jobs").split(',')
        param["Jobs"] = request_utils.array_filter_null(jobs)
        param["SearchWord"] = Config.get_options("operationLog", "default_searchword")
        param["Offset"] = Config.get_options("operationLog", "default_offset")
        param["Limit"] = Config.get_options("operationLog", "default_limit")
        startTime = Config.get_options("operationLog", "default_starttime")
        param["StartTime"] = request_utils.none_and_null(startTime)
        endTime = Config.get_options("operationLog", "default_endtime")
        param["EndTime"] = request_utils.none_and_null(endTime)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 查询日志操作（jobID为空）
    def testOperationLogJobIDNULl(self):
        print "testOperationLogJobIDNULl"
        # 拼接数据
        param = {}
        param["Action"] = "OperationLog"
        param["Jobs"] = []
        param["SearchWord"] = Config.get_options("operationLog", "default_searchword")
        param["Offset"] = Config.get_options("operationLog", "default_offset")
        param["Limit"] = Config.get_options("operationLog", "default_limit")
        startTime = Config.get_options("operationLog", "default_starttime")
        param["StartTime"] = request_utils.none_and_null(startTime)
        endTime = Config.get_options("operationLog", "default_endtime")
        param["EndTime"] = request_utils.none_and_null(endTime)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 查询日志操作（SearchWord未设置）
    def testOperationLogSearchWordNotSet(self):
        print "testOperationLogSearchWordNotSet"
        # 拼接数据
        param = {}
        param["Action"] = "OperationLog"
        jobs = Config.get_options("operationLog", "default_jobs").split(',')
        param["Jobs"] = request_utils.array_filter_null(jobs)
        param["Offset"] = Config.get_options("operationLog", "default_offset")
        param["Limit"] = Config.get_options("operationLog", "default_limit")
        startTime = Config.get_options("operationLog", "default_starttime")
        param["StartTime"] = request_utils.none_and_null(startTime)
        endTime = Config.get_options("operationLog", "default_endtime")
        param["EndTime"] = request_utils.none_and_null(endTime)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 查询日志操作（偏移量不合法）
    def testOperationLogOffsetFormat(self):
        print "testOperationLogOffsetFormat"
        # 拼接数据
        param = {}
        param["Action"] = "OperationLog"
        jobs = Config.get_options("operationLog", "default_jobs").split(',')
        param["Jobs"] = request_utils.array_filter_null(jobs)
        param["Offset"] = Config.get_options("describeInstances", "offset_format_error")
        param["Limit"] = Config.get_options("operationLog", "default_limit")
        startTime = Config.get_options("operationLog", "default_starttime")
        param["StartTime"] = request_utils.none_and_null(startTime)
        endTime = Config.get_options("operationLog", "default_endtime")
        param["EndTime"] = request_utils.none_and_null(endTime)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100026")
        self.assertEquals(result["status_code"], 200)

    # 查询日志操作（Limit不合法）
    def testOperationLogLimitFormat(self):
        print "testOperationLogLimitFormat"
        # 拼接数据
        param = {}
        param["Action"] = "OperationLog"
        jobs = Config.get_options("operationLog", "default_jobs").split(',')
        param["Jobs"] = request_utils.array_filter_null(jobs)
        param["Offset"] = Config.get_options("operationLog", "default_offset")
        param["Limit"] = Config.get_options("describeInstances", "limit_fromat_error")
        startTime = Config.get_options("operationLog", "default_starttime")
        param["StartTime"] = request_utils.none_and_null(startTime)
        endTime = Config.get_options("operationLog", "default_endtime")
        param["EndTime"] = request_utils.none_and_null(endTime)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100027")
        self.assertEquals(result["status_code"], 200)

    # 查询日志操作（参数都为空）
    def testOperationLogDefaultNull(self):
        print "testOperationLogDefaultNull"
        # 拼接数据
        param = {}
        param["Action"] = "OperationLog"
        param["Jobs"] = []
        param["SearchWord"] = ''
        param["Offset"] = ''
        param["Limit"] = ''
        startTime = Config.get_options("operationLog", "default_starttime")
        if ("null" == startTime):
            startTime = ''
        param["StartTime"] = startTime
        endTime = Config.get_options("operationLog", "default_endtime")
        if ("null" == endTime):
            endTime = ''
        param["EndTime"] = endTime
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 查询日志操作（参数都未设置）
    def testOperationLogNotSetAll(self):
        print "testOperationLogNotSetAll"
        # 拼接数据
        param = {}
        param["Action"] = "OperationLog"
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 查询日志操作（jobid格式错误）
    def testOperationLogJobIdError(self):
        print "testOperationLogJobIdError"
        # 拼接数据
        param = {}
        param["Action"] = "OperationLog"
        param["Jobs"] = Config.get_options("operationLog", "default_jobs")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100029")
        self.assertEquals(result["status_code"], 200)

    # 查询日志操作（jobid20个）
    def testOperationLogJobId20(self):
        print "testOperationLogJobId20"
        # 拼接数据
        param = {}
        param["Action"] = "OperationLog"
        jobs = Config.get_options("operationLog", "default_jobs").split(',')
        param["Jobs"] = request_utils.array_filter_null(jobs)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 查询日志操作（jobid21个）
    def testOperationLogJobId21(self):
        print "testOperationLogJobId21"
        # 拼接数据
        param = {}
        param["Action"] = "OperationLog"
        jobs = Config.get_options("operationLog", "default_jobs").split(',')
        param["Jobs"] = request_utils.array_filter_null(jobs)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100029")
        self.assertEquals(result["status_code"], 200)

    # 查询日志操作（状态错误）
    def testOperationLogStatusError(self):
        print "testOperationLogStatusError"
        # 拼接数据
        param = {}
        param["Action"] = "OperationLog"
        param["Status"] = Config.get_options("operationLog", "status_error")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100034")
        self.assertEquals(result["status_code"], 200)

    # 查询日志操作（开始时间大于截止时间且格式错误）
    def testOperationLogTimeError(self):
        print "testOperationLogTimeError"
        # 拼接数据
        param = {}
        param["Action"] = "OperationLog"
        param["Status"] = Config.get_options("operationLog", "default_status")
        startTime = request_utils.none_and_null(Config.get_options("operationLog", "starttime_error"))
        param["StartTime"] = request_utils.local_to_utc(time.mktime(time.strptime(startTime, '%Y-%m-%d %H:%M:%S')))
        endTime = request_utils.none_and_null(Config.get_options("operationLog", "endtime_error"))
        param["EndTime"] = request_utils.local_to_utc(time.mktime(time.strptime(endTime, '%Y-%m-%d %H:%M:%S')))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100024")
        self.assertEquals(result["status_code"], 200)

    # 查询日志操作（开始时间格式错误）
    def testOperationLogsTimeFormatError(self):
        print "testOperationLogsTimeFormatError"
        # 拼接数据
        param = {}
        param["Action"] = "OperationLog"
        param["Status"] = Config.get_options("operationLog", "default_status")
        param["StartTime"] = request_utils.none_and_null(Config.get_options("operationLog", "stime_format"))
        endTime = request_utils.none_and_null(Config.get_options("operationLog", "endtime_error"))
        param["EndTime"] = request_utils.local_to_utc(time.mktime(time.strptime(endTime, '%Y-%m-%d %H:%M:%S')))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100024")
        self.assertEquals(result["status_code"], 200)

    # 查询日志操作（结束格式错误）
    def testOperationLogeTimeFormatError(self):
        print "testOperationLogeTimeFormatError"
        # 拼接数据
        param = {}
        param["Action"] = "OperationLog"
        param["Status"] = Config.get_options("operationLog", "default_status")
        startTime = request_utils.none_and_null(Config.get_options("operationLog", "starttime_error"))
        param["StartTime"] = request_utils.local_to_utc(time.mktime(time.strptime(startTime, '%Y-%m-%d %H:%M:%S')))
        param["EndTime"] = request_utils.none_and_null(Config.get_options("operationLog", "etime_error"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100024")
        self.assertEquals(result["status_code"], 200)

    # 查询日志操作（开始时间未设置，结束日期正确,但是没有结果）
    def testOperationLogsTimeNotSet(self):
        print "testOperationLogsTimeNotSet"
        # 拼接数据
        param = {}
        param["Action"] = "OperationLog"
        param["Status"] = Config.get_options("operationLog", "default_status")
        endTime = request_utils.none_and_null(Config.get_options("operationLog", "endtime"))
        param["EndTime"] = request_utils.local_to_utc(time.mktime(time.strptime(endTime, '%Y-%m-%d %H:%M:%S')))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100025")
        # 判断是是否是成功
        if result["data"]["Code"] == "0":
            print "run ok!"
        self.assertEquals(result["status_code"], 200)

    # 查询日志操作（结束时间未设置，开始日期正确）
    def testOperationLogEndTimeNotSet(self):
        print "testOperationLogEndTimeNotSet"
        # 拼接数据
        param = {}
        param["Action"] = "OperationLog"
        param["Status"] = Config.get_options("operationLog", "default_status")
        startTime = request_utils.none_and_null(Config.get_options("operationLog", "starttime"))
        param["StartTime"] = request_utils.local_to_utc(time.mktime(time.strptime(startTime, '%Y-%m-%d %H:%M:%S')))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 查询日志操作（查询六个月以前的数据）
    def testOperationLogsHistoryData(self):
        print "testOperationLogsHistoryData"
        # 拼接数据
        param = {}
        param["Action"] = "OperationLog"
        param["Status"] = Config.get_options("operationLog", "default_status")
        endTime = request_utils.none_and_null(Config.get_options("operationLog", "endtime_history"))
        param["EndTime"] = request_utils.local_to_utc(time.mktime(time.strptime(endTime, '%Y-%m-%d %H:%M:%S')))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100025")
        self.assertEquals(result["status_code"], 200)

    # 数据中心下无项目
    # def testCreateInstance_regionNoProLog(self):
    #     print "testCreateInstance_regionNoProLog"
    #     param = {}
    #     param["Action"] = "OperationLog"
    #     param["Status"] = Config.get_options("operationLog", "default_status")
    #     endTime = request_utils.none_and_null(Config.get_options("operationLog", "endtime_history"))
    #     param["EndTime"] = request_utils.local_to_utc(time.mktime(time.strptime(endTime, '%Y-%m-%d %H:%M:%S')))
    #     # 添加公共的参数和signature
    #     param = request_utils.generator_common_param(param)
    #     param["Signature"] = auth.generator_signature(param)
    #     param["Region"] = "beijing03"
    #     print param
    #     # 拼装返回的结果
    #     result = request_utils.request(param)
    #     # 判断是是否是成功
    #     if result["data"]["Code"] == "100030":
    #         print "run ok!"
    #     self.assertEquals(result["status_code"], 200)