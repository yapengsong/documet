#!/usr/bin/env python
# coding: utf-8

from config import Config
from utils import auth, request_utils
import unittest

class ModifyInstanceSubnetTest(unittest.TestCase):

  #修改云主机子网（instanceid不存在的云主机）
   def testModifySubnetIdNotExit(self):
        print "testModifySubnetIdNotExit"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        param["InstanceId"] = Config.get_options("modifyInstanceSubnet", "default_instanceid")
        param["MsubNetId"] = request_utils.none_and_null(Config.get_options("modifyInstanceSubnet", "default_msubnet_id"))
        param["UmsubNetId"] = request_utils.none_and_null(Config.get_options("modifyInstanceSubnet", "default_umsubnet_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110043")
        self.assertEquals(result["status_code"], 200)

   #未设置instanceid
   def testModifySubnetNotSetID(self):
        print "testModifySubnetNotSetID"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        param["MsubNetId"] = request_utils.none_and_null(Config.get_options("modifyInstanceSubnet", "default_msubnet_id"))
        param["UmsubNetId"] = request_utils.none_and_null(Config.get_options("modifyInstanceSubnet", "default_umsubnet_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110042")
        self.assertEquals(result["status_code"], 200)

   #设置instanceid,但是instanceid为空
   def testModifySubnetIDIsNull(self):
        print "testModifySubnetIDIsNull"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstance", "instanceid_null")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["MsubNetId"] = request_utils.none_and_null(Config.get_options("modifyInstanceSubnet", "default_msubnet_id"))
        param["UmsubNetId"] = request_utils.none_and_null(Config.get_options("modifyInstanceSubnet", "default_umsubnet_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110042")
        self.assertEquals(result["status_code"], 200)

   #设置instanceid,但是instanceid格式错误
   def testModifySubnetIDFormatError(self):
        print "testModifySubnetIDFormatError"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstanceSubnet", "instanceid_format_error")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["MsubNetId"] = request_utils.none_and_null(Config.get_options("modifyInstanceSubnet", "default_msubnet_id"))
        param["UmsubNetId"] = request_utils.none_and_null(Config.get_options("modifyInstanceSubnet", "default_umsubnet_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110044")
        self.assertEquals(result["status_code"], 200)

   # 未设置MsubNetId
   def testModifySubnetMsubNetIdNotSet(self):
        print "testModifySubnetMsubNetIdNotSet"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstanceSubnet", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["UmsubNetId"] = request_utils.none_and_null(Config.get_options("modifyInstanceSubnet", "default_umsubnet_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

   # MsubNetId为空
   def testModifySubnetMsubNetIdIsNull(self):
        print "testMsubNetIdIsNull"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstanceSubnet", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["MsubNetId"] = request_utils.none_and_null(Config.get_options("modifyInstanceSubnet", "msubnet_id_null"))
        param["UmsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "default_umsubnet_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

   # MsubNetId格式错误
   def testModifySubnetMsubNetIdFormatError(self):
        print "testModifySubnetMsubNetIdFormatError"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstanceSubnet", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["MsubNetId"] = request_utils.none_and_null(Config.get_options("modifyInstanceSubnet", "default_umsubnet_id"))
        param["UmsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "default_umsubnet_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110057")
        self.assertEquals(result["status_code"], 200)

   # 受管子网已删除
   def testModifySubnetMsubNetIdDeleted(self):
        print "testModifySubnetMsubNetIdDeleted"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstanceSubnet", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["MsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "msubnet_id_delete"))
        param["UmsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "default_umsubnet_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110006")
        self.assertEquals(result["status_code"], 200)

   # 受管子网解绑路由，更换子网成功
   def testModifySubnetUnbandRout(self):
        print "testModifySubnetUnbandRout"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstanceSubnet", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["MsubNetId"] = request_utils.none_and_null(Config.get_options("modifyInstanceSubnet", "msubnetid_unband_rout"))
        param["UmsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "default_umsubnet_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

   # 未设置自管子网
   def testModifySubnetUmsubNetIdNotSet(self):
        print "testModifySubnetUmsubNetIdNotSet"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstanceSubnet", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["MsubNetId"] = request_utils.none_and_null(Config.get_options("modifyInstanceSubnet", "msubnetid_unband_rout"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

   # 自管子网为空
   def testModifySubnetUmsubNetIdNull(self):
        print "testModifySubnetUmsubNetIdNull"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstanceSubnet", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["MsubNetId"] = request_utils.none_and_null(Config.get_options("modifyInstanceSubnet", "msubnetid_unband_rout"))
        param["UmsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "umsubnet_id_null"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

   # 自管子网格式错误
   def testModifySubnetUmsubNetFormatError(self):
        print "testModifySubnetUmsubNetFormatError"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstanceSubnet", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["MsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "msubnetid_unband_rout"))
        param["UmsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "umsubnet_id_error"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110010")
        self.assertEquals(result["status_code"], 200)

   # 自管子网录入的不是自管子网的值
   def testModifySubnetUmsubNetError(self):
        print "testModifySubnetUmsubNetError"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstanceSubnet", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["MsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "msubnetid_unband_rout"))
        param["UmsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "msubnetid_unband_rout"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110058")
        self.assertEquals(result["status_code"], 200)

   # 自管子网录入的自管子网是已删除的值
   def testModifySubnetUmsubNetDeleted(self):
        print "testModifySubnetUmsubNetDeleted"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstanceSubnet", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["MsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "msubnetid_unband_rout"))
        param["UmsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "umsubnet_id_deleted"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110009")
        self.assertEquals(result["status_code"], 200)

   # 自管子网录入的自管子网是其他网络下的子网
   def testModifySubnetUmsubNetOther(self):
        print "testModifySubnetUmsubNetOther"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstanceSubnet", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["MsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "msubnetid_unband_rout"))
        param["UmsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "umsubnet_id_other"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110062")
        self.assertEquals(result["status_code"], 200)

   # 自管子网和受管子网都未设置
   def testModifySubnetNoId(self):
        print "testModifySubnetNoId"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstanceSubnet", "instanceid_test")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110063")
        self.assertEquals(result["status_code"], 200)

   # 自管子网录入的自管子网是其他网络下的子网
   def testModifySubnetUmsubNetAllNull(self):
        print "testModifySubnetUmsubNetAllNull"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstanceSubnet", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["MsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "msubnet_id_null"))
        param["UmsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "umsubnet_id_null"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110063")
        self.assertEquals(result["status_code"], 200)

   # 云主机绑定了公网IP
   def testModifySubnetUmsubNetFloadIp(self):
        print "testModifySubnetUmsubNetFloadIp"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstanceSubnet", "instanceid_float_ip")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["MsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "msubnetid_unband_rout"))
        param["UmsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "umsubnet_id_null"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110059")
        self.assertEquals(result["status_code"], 200)

   # 云主机加入了负载均衡
   def testModifySubnetUmsubNetJoinLoad(self):
        print "testModifySubnetUmsubNetJoinLoad"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstanceSubnet", "instanceid_join_load")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["MsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "msubnetid_unband_rout"))
        param["UmsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "umsubnet_id_null"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110060")
        self.assertEquals(result["status_code"], 200)

   # 云主机作为端口映射
   def testModifySubnetUmsubNetPortMap(self):
        print "testModifySubnetUmsubNetPortMap"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstanceSubnet", "instanceid_port_map")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["MsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "msubnetid_unband_rout"))
        param["UmsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "umsubnet_id_null"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110061")
        self.assertEquals(result["status_code"], 200)

   # 云主机在回收站
   def testModifySubnetUmsubNetRecycle(self):
        print "testModifySubnetUmsubNetRecycle"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstance", "instance_syscle")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["MsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "msubnetid_unband_rout"))
        param["UmsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "umsubnet_id_null"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110069")
        self.assertEquals(result["status_code"], 200)

   # 按需计费的云主机余额不足
   def testInstanceModifySubnetEnough(self):
        print "testInstanceModifySubnetEnough"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstance", "instance_id_enough")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["MsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "msubnetid_unband_rout"))
        param["UmsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "umsubnet_id_null"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100017")
        self.assertEquals(result["status_code"], 200)

   # 包年包月的云主机已到期
   def testInstanceModifySubnetIsExpired(self):
        print "testInstanceModifySubnetIsExpired"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstance", "instance_id_expired")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["MsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "msubnetid_unband_rout"))
        param["UmsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "umsubnet_id_null"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100019")
        self.assertEquals(result["status_code"], 200)

   # 云主机未到期，私有网络已到期
   def testModifySubnetNetWorkIsExpired(self):
        print "testModifySubnetNetWorkIsExpired"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["MsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "msubnetid_unband_rout"))
        param["UmsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "umsubnet_id_null"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

   # 云主机暂停服务或者故障
   def testModifySubnetStatusIsError(self):
        print "testModifySubnetStatusIsError"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstance", "instanceid_error")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["MsubNetId"] = request_utils.none_and_null(Config.get_options("modifyInstanceSubnet", "msubnetid_unband_rout"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110081")
        self.assertEquals(result["status_code"], 200)

   # 不更改子网的原始值
   def testModifySubnetStatusNoChange(self):
        print "testModifySubnetStatusNoChange"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstanceSubnet", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["MsubNetId"] = request_utils.none_and_null(Config.get_options("modifyInstanceSubnet", "msubnetid_unband_rout"))
        param["UmsubNetId"] = request_utils.none_and_null(
             Config.get_options("modifyInstanceSubnet", "default_umsubnet_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

   # 只更改受管子网
   def testModifySubnetStatusOnlyMsubNetId(self):
        print "testModifySubnetStatusOnlyMsubNetId"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstanceSubnet", "instanceid_test")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["MsubNetId"] = request_utils.none_and_null(Config.get_options("modifyInstanceSubnet", "msubnet_id_only"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 只更改自管子网
   def testModifySubnetStatusOnlyUmsubNetId(self):
        print "testModifySubnetStatusOnlyUmsubNetId"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstanceSubnet"
        instanceId = Config.get_options("modifyInstanceSubnet", "instanceid_test")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["UmsubNetId"] = request_utils.none_and_null(Config.get_options("modifyInstanceSubnet", "default_umsubnet_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)