#!/usr/bin/env python
# coding: utf-8

from config import Config
from utils import auth, request_utils
import unittest

class ShutdownInstanceTest(unittest.TestCase):

  #关闭一个instanceid不存在的云主机
   def testShutdownInstance(self):
        print "ShutdownInstance"
        # 拼接数据
        param = {}
        param["Action"] = "ShutdownInstance"
        param["InstanceId"] = Config.get_options("shutdownInstance", "default_instanceid")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110043")
        self.assertEquals(result["status_code"], 200)

   #未设置instanceid
   def testShutdownInstanceNotSetID(self):
        print "testShutdownInstanceNotSetID"
        # 拼接数据
        param = {}
        param["Action"] = "ShutdownInstance"
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110042")
        self.assertEquals(result["status_code"], 200)

   #设置instanceid,但是instanceid为空
   def testShutdownInstanceIDIsNull(self):
        print "testShutdownInstanceIDIsNull"
        # 拼接数据
        param = {}
        param["Action"] = "ShutdownInstance"
        instanceId = Config.get_options("shutdownInstance", "instanceid_null")
        param["InstanceId"] =request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110042")
        self.assertEquals(result["status_code"], 200)

   #设置instanceid,但是instanceid格式错误
   def testShutdownInstanceIDFormatError(self):
        print "testShutdownInstanceIDFormatError"
        # 拼接数据
        param = {}
        param["Action"] = "ShutdownInstance"
        instanceId = Config.get_options("shutdownInstance", "instanceid_format_error")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110044")
        self.assertEquals(result["status_code"], 200)

   #设置instanceid,云主机为关闭状态
   def testShutdownInstanceShutOff(self):
        print "testShutdownInstanceShutOff"
        # 拼接数据
        param = {}
        param["Action"] = "ShutdownInstance"
        instanceId = Config.get_options("shutdownInstance", "instanceid_shutoff")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110048")
        self.assertEquals(result["status_code"], 200)

   # 云主机正在创建自定义镜像
   def testShutdownInstanceCreateImage(self):
        print "testShutdownInstanceCreateImage"
        # 拼接数据
        param = {}
        param["Action"] = "ShutdownInstance"
        instanceId = Config.get_options("shutdownInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110049")
        self.assertEquals(result["status_code"], 200)

   # 云主机故障
   def testShutdownInstanceError(self):
        print "testShutdownInstanceError"
        # 拼接数据
        param = {}
        param["Action"] = "ShutdownInstance"
        instanceId = Config.get_options("shutdownInstance", "instanceid_error")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110048")
        self.assertEquals(result["status_code"], 200)

   # 云主机已到期
   def testShutdownInstanceExpired(self):
        print "testShutdownInstanceExpired"
        # 拼接数据
        param = {}
        param["Action"] = "ShutdownInstance"
        instanceId = Config.get_options("shutdownInstance", "instanceid_expired")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100019")
        self.assertEquals(result["status_code"], 200)

   # 云主机余额不足
   def testShutdownInstanceNotEnough(self):
        print "testShutdownInstanceNotEnough"
        # 拼接数据
        param = {}
        param["Action"] = "ShutdownInstance"
        instanceId = Config.get_options("shutdownInstance", "instanceid_not_enough")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100017")
        self.assertEquals(result["status_code"], 200)