#!/usr/bin/env python
# coding: utf-8

from config import Config
from utils import auth, request_utils
import unittest

class DeleteInstanceTest(unittest.TestCase):

  #关闭一个instanceid不存在的云主机
   def testDeleteInstance(self):
        print "testDeleteInstance"
        # 拼接数据
        param = {}
        param["Action"] = "DeleteInstance"
        param["InstanceId"] = Config.get_options("deleteInstance", "default_instanceid")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110043")
        self.assertEquals(result["status_code"], 200)

   #未设置instanceid
   def testDeleteInstanceNotSetID(self):
        print "testDeleteInstanceNotSetID"
        # 拼接数据
        param = {}
        param["Action"] = "DeleteInstance"
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110042")
        self.assertEquals(result["status_code"], 200)

   #设置instanceid,但是instanceid为空
   def testDeleteInstanceIDIsNull(self):
        print "testDeleteInstanceIDIsNull"
        # 拼接数据
        param = {}
        param["Action"] = "DeleteInstance"
        instanceId = Config.get_options("deleteInstance", "instanceid_null")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        isRecycle = Config.get_options("deleteInstance", "isrecycle_null")
        param["IsRecycle"] =  request_utils.none_and_null(isRecycle)
            # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110042")
        self.assertEquals(result["status_code"], 200)

   #设置instanceid,但是instanceid格式错误
   def testDeleteInstanceIDFormatError(self):
        print "testDeleteInstanceIDFormatError"
        # 拼接数据
        param = {}
        param["Action"] = "DeleteInstance"
        instanceId = Config.get_options("deleteInstance", "instanceid_format_error")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110044")
        self.assertEquals(result["status_code"], 200)

   #设置instanceid,云主机为关闭状态
   def testDeleteInstanceShutOff(self):
        print "testDeleteInstanceShutOff"
        # 拼接数据
        param = {}
        param["Action"] = "DeleteInstance"
        instanceId = Config.get_options("deleteInstance", "instanceid_shutoff")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110048")
        self.assertEquals(result["status_code"], 200)

   # 云主机正在创建自定义镜像
   def testDeleteInstanceCreateImage(self):
        print "testDeleteInstanceCreateImage"
        # 拼接数据
        param = {}
        param["Action"] = "DeleteInstance"
        instanceId = Config.get_options("deleteInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110049")
        self.assertEquals(result["status_code"], 200)

   # 云主机故障
   def testDeleteInstanceError(self):
        print "testDeleteInstanceError"
        # 拼接数据
        param = {}
        param["Action"] = "DeleteInstance"
        instanceId = Config.get_options("deleteInstance", "instanceid_error")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110048")
        self.assertEquals(result["status_code"], 200)

   # 云主机已到期
   def testDeleteInstanceExpired(self):
        print "testDeleteInstanceExpired"
        # 拼接数据
        param = {}
        param["Action"] = "DeleteInstance"
        instanceId = Config.get_options("deleteInstance", "instanceid_expired")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100019")
        self.assertEquals(result["status_code"], 200)

   # 云主机余额不足
   def testDeleteInstanceNotEnough(self):
        print "testDeleteInstanceNotEnough"
        # 拼接数据
        param = {}
        param["Action"] = "DeleteInstance"
        instanceId = Config.get_options("deleteInstance", "instanceid_not_enough")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100017")
        self.assertEquals(result["status_code"], 200)

   # IsRecycle参数格式错误
   def testDeleteInstanceIsRecycleFormat(self):
        print "testDeleteInstanceIsRecycleFormat"
        # 拼接数据
        param = {}
        param["Action"] = "DeleteInstance"
        instanceId = Config.get_options("deleteInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["IsRecycle"] =Config.get_options("deleteInstance", "isrecycle_format_error")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110051")
        self.assertEquals(result["status_code"], 200)

   # 余额不足的云主机彻底删除
   def testDeleteInstanceNotEnoughDelete(self):
        print "testDeleteInstanceNotEnoughDelete"
        # 拼接数据
        param = {}
        param["Action"] = "DeleteInstance"
        instanceId = Config.get_options("deleteInstance", "delete_recycle1")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["IsRecycle"] =Config.get_options("deleteInstance", "isrecycle_right")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

   # 已到期的云主机彻底删除
   def testDeleteInstanceExpiredDelete(self):
        print "testDeleteInstanceExpiredDelete"
        # 拼接数据
        param = {}
        param["Action"] = "DeleteInstance"
        instanceId = Config.get_options("deleteInstance", "instanceid_expired")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["IsRecycle"] =Config.get_options("deleteInstance", "isrecycle_right")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

   # 已到期的云主机删除进入回收站
   def testDeleteInstanceExpiredRecycle(self):
        print "testDeleteInstanceExpiredRecycle"
        # 拼接数据
        param = {}
        param["Action"] = "DeleteInstance"
        instanceId = Config.get_options("deleteInstance", "instanceid_expired")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["IsRecycle"] =Config.get_options("deleteInstance", "default_isrecycle")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100019")
        self.assertEquals(result["status_code"], 200)

   # 云主机正在创建自定义镜像
   def testDeleteInstanceNotExpired(self):
        print "testDeleteInstanceNotExpired"
        # 拼接数据
        param = {}
        param["Action"] = "DeleteInstance"
        instanceId = Config.get_options("deleteInstance", "instanceid_not_expired")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["IsRecycle"] =Config.get_options("deleteInstance", "default_isrecycle")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110052")
        self.assertEquals(result["status_code"], 200)

   # 云主机绑定了公网IP/负载均衡/云硬盘/云监控
   def testDeleteInstanceHaveFloatIP(self):
        print "testDeleteInstanceHaveFloatIP"
        # 拼接数据
        param = {}
        param["Action"] = "DeleteInstance"
        instanceId = Config.get_options("deleteInstance", "instanceid_ip")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["IsRecycle"] =Config.get_options("deleteInstance", "default_isrecycle")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

   # 云主机暂停服务(云主机必须为ACTIVE、ERROR、SHUTOFF)
   def testDeleteInstanceNotService(self):
        print "testDeleteInstanceNotService"
        # 拼接数据
        param = {}
        param["Action"] = "DeleteInstance"
        instanceId = Config.get_options("deleteInstance", "instanceid_ip")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["IsRecycle"] =Config.get_options("deleteInstance", "default_isrecycle")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110080")
        self.assertEquals(result["status_code"], 200)