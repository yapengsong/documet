#!/usr/bin/env python
# coding: utf-8

from config import Config
from utils import auth, request_utils
import unittest
import datetime


class ComputeApiTest(unittest.TestCase):

    # 创建云主机（按需付费）
    def testCreateInstance(self):
        print "testCreateInstance"
        param = {}
        param = request_utils.generator_compute(param)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        #print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        # 判断是是否是成功
        if result["data"]["Code"] == "100006":# ak处于禁用状态
            print "run ok!"
        elif result["data"]["Code"] == "110079":# 按需的购买账户余额未达到按需购买的条件
            print "run ok!"
        elif result["data"]["Code"] == "100018": # 账号冻结
            print "run ok!"
        elif result["data"]["Code"] == "100036":# IP在黑名单
            print "run ok!"
        elif result["data"]["Code"] == "100035": # 客户在黑名单中
            print "run ok!"
        elif result["data"]["Code"] == "100009":# api访问次数已用完
            print "run ok!"
        elif result["data"]["Code"] == "100007":# 找不到ak对应的sk（redis中删除，sk测试意义不大，且自动化也无法实现）
            print "run ok!"
        elif result["data"]["Code"] == "110029": # 云主机名称已经存在
            print "run ok!"
        elif result["data"]["Code"] == "110036":# 云主机数量超配
            print "run ok!"
        elif result["data"]["Code"] == "110037":# CPU超过配额
            print "run ok!"
        elif result["data"]["Code"] == "110038":# 内存超配
            print "run ok!"
        elif result["data"]["Code"] == "110040":# 云硬盘数量超配
            print "run ok!"
        elif result["data"]["Code"] == "110041":# 云硬盘容量超配
            print "run ok!"
        elif result["data"]["Code"] == "500002":
            print "run ok!"
        elif result["data"]["Code"] == "500001":# 获取单价失败
            print "run ok!"
        elif result["data"]["Code"] == "500003":
            print "run ok!"
        self.assertEquals(result["status_code"], 200)

    # 创建云主机（公网IP超配）
    def testCreateInstancePayFloatIP(self):
        print "testCreateInstancePayFloatIP"
        param = {}
        param = request_utils.generator_compute(param)
        param["InstanceName"] = Config.get_options("compute", "instance_name_error")
        param["PayType"] = Config.get_options("compute", "pay_month")
        param["Payduration"] = Config.get_options("compute", "payduration")
        param["FloatIP"] = Config.get_options("compute", "floatip_goumai")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110039")
        self.assertEquals(result["status_code"], 200)

    # 创建云主机（包年包月账户余额不足）
    def testPayMonthNotEnough(self):
        print "testPayMonthNotEnough"
        param = {}
        param = request_utils.generator_compute(param)
        param["InstanceName"] = Config.get_options("compute", "instance_name_error")
        param["PayType"] = Config.get_options("compute", "pay_month")
        param["Payduration"] = Config.get_options("compute", "payduration")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110078")
        self.assertEquals(result["status_code"], 200)

    # 创建云主机（包年包月创建成功）
    def testPayMonthSuccess(self):
        print "testPayMonthSuccess"
        param = {}
        param = request_utils.generator_compute(param)
        param["InstanceName"] = Config.get_options("compute", "name_month")
        param["PayType"] = Config.get_options("compute", "pay_month")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 创建云主机（镜像未就绪状态）
    def testImageCreating(self):
        print "testImageCreating"
        param = {}
        param["Action"] = "CreateInstance"
        param["VPCId"] = Config.get_options("compute", "default_vpcid")
        param["MsubNetId"] = Config.get_options("compute", "default_msub_netid")
        param["ImageType"] = Config.get_options("compute", "image_type_define")
        param["ImageId"] = Config.get_options("compute", "image_create_id")
        param["CPU"] = Config.get_options("compute", "default_cpu_count")
        param["Memory"] = Config.get_options("compute", "default_mem_size")
        param["LoginMode"] = Config.get_options("compute", "default_login_mode")
        param["Password"] = Config.get_options("compute", "default_password")
        param["InstanceName"] = Config.get_options("compute", "default_instance_name")
        param["PayType"] = Config.get_options("compute", "default_pay_type")
        param["InstanceName"] = Config.get_options("compute", "name_month")
        param["PayType"] = Config.get_options("compute", "pay_month")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110073")
        self.assertEquals(result["status_code"], 200)

    # 创建云主机（公共镜像已停用）
    def testImageComStop(self):
        print "testImageComStop"
        param = {}
        param["Action"] = "CreateInstance"
        param["VPCId"] = Config.get_options("compute", "default_vpcid")
        param["MsubNetId"] = Config.get_options("compute", "default_msub_netid")
        param["ImageId"] = Config.get_options("compute", "image_stop")
        param["CPU"] = Config.get_options("compute", "default_cpu_count")
        param["Memory"] = Config.get_options("compute", "default_mem_size")
        param["LoginMode"] = Config.get_options("compute", "default_login_mode")
        param["Password"] = Config.get_options("compute", "default_password")
        param["InstanceName"] = Config.get_options("compute", "default_instance_name")
        param["PayType"] = Config.get_options("compute", "default_pay_type")
        param["InstanceName"] = Config.get_options("compute", "name_month")
        param["PayType"] = Config.get_options("compute", "pay_month")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110146")
        self.assertEquals(result["status_code"], 200)

    # 创建云主机（市场镜像已停用）
    def testImageStop(self):
        print "testImageStop"
        param = {}
        param["Action"] = "CreateInstance"
        param["VPCId"] = Config.get_options("compute", "default_vpcid")
        param["MsubNetId"] = Config.get_options("compute", "default_msub_netid")
        param["ImageType"] = Config.get_options("compute", "image_type")
        param["ImageId"] = Config.get_options("compute", "image_stop")
        param["CPU"] = Config.get_options("compute", "default_cpu_count")
        param["Memory"] = Config.get_options("compute", "default_mem_size")
        param["LoginMode"] = Config.get_options("compute", "default_login_mode")
        param["Password"] = Config.get_options("compute", "default_password")
        param["InstanceName"] = Config.get_options("compute", "default_instance_name")
        param["PayType"] = Config.get_options("compute", "default_pay_type")
        param["InstanceName"] = Config.get_options("compute", "name_month")
        param["PayType"] = Config.get_options("compute", "pay_month")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110146")
        self.assertEquals(result["status_code"], 200)

    # 创建云主机（镜像删除中）
    def testImageDeleting(self):
        print "testImageDeleting"
        param = {}
        param["Action"] = "CreateInstance"
        param["VPCId"] = Config.get_options("compute", "default_vpcid")
        param["MsubNetId"] = Config.get_options("compute", "default_msub_netid")
        param["ImageType"] = Config.get_options("compute", "image_type_define")
        param["ImageId"] = Config.get_options("compute", "image_delete")
        param["CPU"] = Config.get_options("compute", "default_cpu_count")
        param["Memory"] = Config.get_options("compute", "default_mem_size")
        param["LoginMode"] = Config.get_options("compute", "default_login_mode")
        param["Password"] = Config.get_options("compute", "default_password")
        param["InstanceName"] = Config.get_options("compute", "default_instance_name")
        param["PayType"] = Config.get_options("compute", "default_pay_type")
        param["InstanceName"] = Config.get_options("compute", "name_month")
        param["PayType"] = Config.get_options("compute", "pay_month")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110147")
        self.assertEquals(result["status_code"], 200)

    # 创建云主机（私有网络未设置外网网关）
    def testNetWorkNotSetGateWay(self):
        print "testNetWorkNotSetGateWay"
        param = {}
        param = request_utils.generator_compute(param)
        param["InstanceName"] = Config.get_options("compute", "name_gateway")
        param["VPCId"] = Config.get_options("compute", "vpcid_not_gateway")
        param["MsubNetId"] = Config.get_options("compute", "dmsub_netid_not_gateway")
        param["PayType"] = Config.get_options("compute", "pay_month")
        param["Payduration"] = Config.get_options("compute", "payduration")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110012")
        self.assertEquals(result["status_code"], 200)

    # 私有网络ID不存在此数据中心下
    def testvpcIdNotExist(self):
        print "testvpcIdNotExist"
        param = {}
        param = request_utils.generator_compute(param)
        param["VPCId"] = Config.get_options("compute", "vpcid_notexit")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
       # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110001")
        # 判断是是否是成功
        if result["data"]["Code"] == "110008":
            print "run ok!"
        self.assertEquals(result["status_code"], 200)

    # 私有网络id为已删除的私有网络id
    def testvpcIdisDelete(self):
        print "testvpcIdisDelete"
        param = {}
        param = request_utils.generator_compute(param)
        param["VPCId"] = Config.get_options("compute", "vpcid_error")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
       # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110008")
        self.assertEquals(result["status_code"], 200)

    # 未设置私有网络id的参数
    def testNotSetVpcId(self):
        print "testNotSetVpcId"
        param = {}
        param["Action"] = "CreateInstance"
        param["MsubNetId"] = Config.get_options("compute", "default_msub_netid")
        param["ImageId"] = Config.get_options("compute", "default_image_id")
        param["CPU"] = Config.get_options("compute", "default_cpu_count")
        param["Memory"] = Config.get_options("compute", "default_mem_size")
        param["LoginMode"] = Config.get_options("compute", "default_login_mode")
        param["Password"] = Config.get_options("compute", "default_password")
        param["InstanceName"] = Config.get_options("compute", "default_instance_name")
        param["PayType"] = Config.get_options("compute", "default_pay_type")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
       # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110002")
        self.assertEquals(result["status_code"], 200)

    # 私有网络id格式错误
    def testvpcIdFormatError(self):
        print "testvpcIdFormatError"
        param = {}
        param = request_utils.generator_compute(param)
        param["VPCId"] = Config.get_options("compute", "vpcid_formaterror")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        #print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110003")
        self.assertEquals(result["status_code"], 200)

    # 受管子网id未设置
    def testNotSetMsubNetId(self):
        print "testNotSetMsubNetId"
        param = {}
        param["Action"] = "CreateInstance"
        param["VPCId"] = Config.get_options("compute", "default_vpcid")
        param["ImageId"] = Config.get_options("compute", "default_image_id")
        param["CPU"] = Config.get_options("compute", "default_cpu_count")
        param["Memory"] = Config.get_options("compute", "default_mem_size")
        param["LoginMode"] = Config.get_options("compute", "default_login_mode")
        param["Password"] = Config.get_options("compute", "default_password")
        param["InstanceName"] = Config.get_options("compute", "default_instance_name")
        param["PayType"] = Config.get_options("compute", "default_pay_type")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
       # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110004")
        self.assertEquals(result["status_code"], 200)

    # 受管子网id格式错误
    def testMsubNetIdFormatError(self):
        print "testMsubNetIdFormatError"
        param = {}
        param = request_utils.generator_compute(param)
        param["MsubNetId"] = Config.get_options("compute", "mubnetid_formaterror")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        #print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110005")
        self.assertEquals(result["status_code"], 200)

    # 受管子网为已删除子网的ID
    def testMsubNetIdisDeleted(self):
        print "testMsubNetIdisDeleted"
        param = {}
        param = request_utils.generator_compute(param)
        param["MsubNetId"] = Config.get_options("compute", "mubnetid_isdeleted")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        #print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110006")
        self.assertEquals(result["status_code"], 200)

     # 受管子网断开路由
    def testMsubNetIdLeaveRute(self):
        print "testMsubNetIdLeaveRute"
        param = {}
        param = request_utils.generator_compute(param)
        param["MsubNetId"] = Config.get_options("compute", "mubnetid_leaverute")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        #print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110007")
        self.assertEquals(result["status_code"], 200)

    # 自管子网为已删除子网
    def testUmsubNetIdNotExit(self):
        print "testUmsubNetIdNotExit"
        param = {}
        param = request_utils.generator_compute(param)
        param["UmsubNetId"] = Config.get_options("compute", "umsubnetid_notexit")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        #print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110009")
        self.assertEquals(result["status_code"], 200)

    # 自管子网格式错误
    def testUmsubNetIFormatError(self):
        print "testUmsubNetIFormatError"
        param = {}
        param = request_utils.generator_compute(param)
        param["UmsubNetId"] = Config.get_options("compute", "umsubnetid_formaterror")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        #print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110010")
        self.assertEquals(result["status_code"], 200)

    # 弹性公网IP格式错误
    def testFloatIPFormatError(self):
        print "testFloatIPFormatError"
        param = {}
        param = request_utils.generator_compute(param)
        param["FloatIP"] = Config.get_options("compute", "floatip_roematerror")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        #print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110011")
        self.assertEquals(result["status_code"], 200)

    # 私有网络没有设置外网网关(购买了弹性公网ip，但是网络未设置网关)
    def testcpvNotSetNetgateway(self):
        print "testcpvNotSetNetgateway"
        param = {}
        param["Action"] = "CreateInstance"
        param["VPCId"] = Config.get_options("compute", "default_vpcid")
        param["MsubNetId"] = Config.get_options("compute", "default_msub_netid")
        param["CPU"] = Config.get_options("compute", "default_cpu_count")
        param["Memory"] = Config.get_options("compute", "default_mem_size")
        param["LoginMode"] = Config.get_options("compute", "default_login_mode")
        param["Password"] = Config.get_options("compute", "default_password")
        param["InstanceName"] = Config.get_options("compute", "default_instance_name")
        param["PayType"] = Config.get_options("compute", "default_pay_type")
        param["FloatIP"] = "1"
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        #print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110012")
        self.assertEquals(result["status_code"], 200)

    # 未设置ImageId字段
    def testImageIdNotSet(self):
        print "testImageIdNotSet"
        param = {}
        param["Action"] = "CreateInstance"
        param["VPCId"] = Config.get_options("compute", "default_vpcid")
        param["MsubNetId"] = Config.get_options("compute", "default_msub_netid")
        param["CPU"] = Config.get_options("compute", "default_cpu_count")
        param["Memory"] = Config.get_options("compute", "default_mem_size")
        param["LoginMode"] = Config.get_options("compute", "default_login_mode")
        param["Password"] = Config.get_options("compute", "default_password")
        param["InstanceName"] = Config.get_options("compute", "default_instance_name")
        param["PayType"] = Config.get_options("compute", "default_pay_type")
        param["FloatIP"] = "0"
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        #print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110014")
        self.assertEquals(result["status_code"], 200)

    # 镜像id不存在
    def testImageIdNotExit(self):
        print "testImageIdNotExit"
        param = {}
        param = request_utils.generator_compute(param)
        param["ImageId"] = Config.get_options("compute", "imagedid_notexit")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        #print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110016")
        self.assertEquals(result["status_code"], 200)

    # 不支持的cpu和内存的规格
    def testCpuAndMemoryNonstandard(self):
        print "testCpuAndMemoryNonstandard"
        param = {}
        param = request_utils.generator_compute(param)
        param["CPU"] = Config.get_options("compute", "cpu_not")
        param["Memory"] = Config.get_options("compute", "mem_not")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110018")
        self.assertEquals(result["status_code"], 200)

    # 镜像id格式错误
    def testImageIdFormatError(self):
        print "testImageIdFormatError"
        param = {}
        param = request_utils.generator_compute(param)
        param["ImageId"] = Config.get_options("compute", "imagedid_formaterror")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
       # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110017")
        self.assertEquals(result["status_code"], 200)

    # 镜像类型格式错误
    def testImageTypeFormatError(self):
        print "testImageTypeFormatError"
        param = {}
        param = request_utils.generator_compute(param)
        param["ImageType"] = Config.get_options("compute", "imagetype_formaterror")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
       # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110015")
        self.assertEquals(result["status_code"], 200)

    # 未设置cpu字段
    def testCPUNotSet(self):
        print "testCPUNotSet"
        param = {}
        param["Action"] = "CreateInstance"
        param["VPCId"] = Config.get_options("compute", "default_vpcid")
        param["MsubNetId"] = Config.get_options("compute", "default_msub_netid")
        param["ImageId"] = Config.get_options("compute", "default_image_id")
        param["Memory"] = Config.get_options("compute", "default_mem_size")
        param["LoginMode"] = Config.get_options("compute", "default_login_mode")
        param["Password"] = Config.get_options("compute", "default_password")
        param["InstanceName"] = Config.get_options("compute", "default_instance_name")
        param["PayType"] = Config.get_options("compute", "default_pay_type")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
       # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110085")
        self.assertEquals(result["status_code"], 200)

    # 未设置内存字段
    def testMemoryNotSet(self):
        print "testMemoryNotSet"
        param = {}
        param["Action"] = "CreateInstance"
        param["VPCId"] = Config.get_options("compute", "default_vpcid")
        param["MsubNetId"] = Config.get_options("compute", "default_msub_netid")
        param["ImageId"] = Config.get_options("compute", "default_image_id")
        param["CPU"] = Config.get_options("compute", "default_cpu_count")
        param["LoginMode"] = Config.get_options("compute", "default_login_mode")
        param["Password"] = Config.get_options("compute", "default_password")
        param["InstanceName"] = Config.get_options("compute", "default_instance_name")
        param["PayType"] = Config.get_options("compute", "default_pay_type")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        #print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110086")
        self.assertEquals(result["status_code"], 200)

    # 设置内存和cpu大于镜像的最大值的规格
    def testMemoryAndCPUTooBig(self):
        print "testMemoryAndCPUTooBig"
        param = {}
        param = request_utils.generator_compute(param)
        param["CPU"] = Config.get_options("compute", "cpu_big")
        param["Memory"] = Config.get_options("compute", "mem_big")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110019")
        self.assertEquals(result["status_code"], 200)

     # 设置内存和cpu小于镜像的最小值的规格
    def testMemoryAndCPUSmall(self):
        print "testMemoryAndCPUSmall"
        param = {}
        param = request_utils.generator_compute(param)
        param["CPU"] = Config.get_options("compute", "cpu_small")
        param["Memory"] = Config.get_options("compute", "mem_small")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
       # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110020")
        self.assertEquals(result["status_code"], 200)

    #LoginMode字段未设置
    def testLoginModeNotSet(self):
        print "testLoginModeNotSet"
        param = {}
        param["Action"] = "CreateInstance"
        param["VPCId"] = Config.get_options("compute", "default_vpcid")
        param["MsubNetId"] = Config.get_options("compute", "default_msub_netid")
        param["ImageId"] = Config.get_options("compute", "default_image_id")
        param["CPU"] = Config.get_options("compute", "default_cpu_count")
        param["Memory"] = Config.get_options("compute", "default_mem_size")
        param["Password"] = Config.get_options("compute", "default_password")
        param["InstanceName"] = Config.get_options("compute", "default_instance_name")
        param["PayType"] = Config.get_options("compute", "default_pay_type")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
       # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110021")
        self.assertEquals(result["status_code"], 200)

    # LoginMode字段格式错误
    def testLoginModeFormatError(self):
        print "testLoginModeFormatError"
        param = {}
        param["Action"] = "CreateInstance"
        param["VPCId"] = Config.get_options("compute", "default_vpcid")
        param["MsubNetId"] = Config.get_options("compute", "default_msub_netid")
        param["ImageId"] = Config.get_options("compute", "default_image_id")
        param["CPU"] = Config.get_options("compute", "default_cpu_count")
        param["Memory"] = Config.get_options("compute", "default_mem_size")
        param["Password"] = Config.get_options("compute", "default_password")
        param["InstanceName"] = Config.get_options("compute", "default_instance_name")
        param["PayType"] = Config.get_options("compute", "default_pay_type")
        param["LoginMode"] = Config.get_options("compute", "loginmode_formaterror")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110022")
        self.assertEquals(result["status_code"], 200)

    # password字段未设置
    def testPasswordNotSet(self):
        print "testPasswordNotSet"
        param = {}
        param["Action"] = "CreateInstance"
        param["VPCId"] = Config.get_options("compute", "default_vpcid")
        param["MsubNetId"] = Config.get_options("compute", "default_msub_netid")
        param["ImageId"] = Config.get_options("compute", "default_image_id")
        param["CPU"] = Config.get_options("compute", "default_cpu_count")
        param["Memory"] = Config.get_options("compute", "default_mem_size")
        param["InstanceName"] = Config.get_options("compute", "default_instance_name")
        param["PayType"] = Config.get_options("compute", "default_pay_type")
        param["LoginMode"] = Config.get_options("compute", "default_login_mode")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        #print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110025")
        self.assertEquals(result["status_code"], 200)

    # password字段格式错误
    def testPasswordFormatError(self):
        print "testPasswordFormatError"
        param = {}
        param = request_utils.generator_compute(param)
        param["Password"] = Config.get_options("compute", "password_error")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110026")
        self.assertEquals(result["status_code"], 200)

    # InstanceName字段未设置
    def testInstanceNameNotSet(self):
        print "testInstanceNameNotSet"
        param = {}
        param["Action"] = "CreateInstance"
        param["VPCId"] = Config.get_options("compute", "default_vpcid")
        param["MsubNetId"] = Config.get_options("compute", "default_msub_netid")
        param["ImageId"] = Config.get_options("compute", "default_image_id")
        param["CPU"] = Config.get_options("compute", "default_cpu_count")
        param["Memory"] = Config.get_options("compute", "default_mem_size")
        param["Password"] = Config.get_options("compute", "default_password")
        param["PayType"] = Config.get_options("compute", "default_pay_type")
        param["LoginMode"] = Config.get_options("compute", "default_login_mode")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110027")
        self.assertEquals(result["status_code"], 200)

     # InstanceName字段格式错误（此字段去掉）
    # def testInstanceNameFormatError(self):
    #     print "testInstanceNameFormatError"
    #     param = {}
    #     param = request_utils.generator_compute(param)
    #     param["InstanceName"] = Config.get_options("compute", "instancename_format_error")
    #     # 添加公共的参数和signature
    #     param = request_utils.generator_common_param(param)
    #     param["Signature"] = auth.generator_signature(param)
    #     # print param
    #     # 拼装返回的结果
    #     result = request_utils.request(param)
    #     # 判断是是否是成功
    #     if result["data"]["Code"] == "110028":
    #         print "run ok!"
    #     self.assertEquals(result["status_code"], 200)

    # Instanceremark字段格式错误（此字段从接口中去掉）
    # def testInstanceRemarkFormatError(self):
    #     print "testInstanceRemarkFormatError"
    #     param = {}
    #     param = request_utils.generator_compute(param)
    #     param["InsanceRemark"] = Config.get_options("compute", "instance_remark_error")
    #     # 添加公共的参数和signature
    #     param = request_utils.generator_common_param(param)
    #     param["Signature"] = auth.generator_signature(param)
    #     print param
    #     # 拼装返回的结果
    #     result = request_utils.request(param)
    #     # 判断是是否是成功
    #     if result["data"]["Code"] == "110030":
    #         print "run ok!"
    #     self.assertEquals(result["status_code"], 200)

    # SecurityGroupName格式错误
    def testSecurityGroupNameFormatError(self):
        print "testSecurityGroupNameFormatError"
        param = {}
        param = request_utils.generator_compute(param)
        param["SecurityGroupName"] = Config.get_options("compute", "security_groupname_error")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110077")
        self.assertEquals(result["status_code"], 200)

    # 未设置计费方式（PayType）
    def testPayTypeNotSet(self):
        print "testPayTypeNotSet"
        param = {}
        param["Action"] = "CreateInstance"
        param["VPCId"] = Config.get_options("compute", "default_vpcid")
        param["MsubNetId"] = Config.get_options("compute", "default_msub_netid")
        param["ImageId"] = Config.get_options("compute", "default_image_id")
        param["CPU"] = Config.get_options("compute", "default_cpu_count")
        param["Memory"] = Config.get_options("compute", "default_mem_size")
        param["LoginMode"] = Config.get_options("compute", "default_login_mode")
        param["Password"] = Config.get_options("compute", "default_password")
        param["InstanceName"] = "test789"
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110032")
        self.assertEquals(result["status_code"], 200)

    # 批量创建云主机
    # def testcreateInstanceBatch(self):
    #     print "testcreateInstanceBatch"
    #     param = {}
    #     param["Action"] = "CreateInstance"
    #     param["VPCId"] = Config.get_options("compute", "default_vpcid")
    #     param["MsubNetId"] = Config.get_options("compute", "default_msub_netid")
    #     param["ImageId"] = Config.get_options("compute", "default_image_id")
    #     param["CPU"] = Config.get_options("compute", "default_cpu_count")
    #     param["Memory"] = Config.get_options("compute", "default_mem_size")
    #     param["LoginMode"] = Config.get_options("compute", "default_login_mode")
    #     param["Password"] = Config.get_options("compute", "default_password")
    #     param["InstanceName"] = "test333"
    #     param["Count"] = "20"
    #     param["PayType"] = Config.get_options("compute", "default_pay_type")
    #
    #     # 添加公共的参数和signature
    #     param = request_utils.generator_common_paramTwo(param,"","","")
    #     param["Signature"] = auth.generator_signatureTwo(param,"")
    #     print param
    #     # 拼装返回的结果
    #     result = request_utils.request_post(param,None,"0")
    #     # 判断是是否是成功
    #      if result["data"]["Code"] == "500003":
    #      print "run ok!"
    #     self.assertEquals(result["status_code"], 200)

    # count格式错误
    def testCreateCountFormatError(self):
        print "testCreateCountFormatError"
        param = {}
        param = request_utils.generator_compute(param)
        param["Count"] = Config.get_options("compute", "count_error")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110031")
        self.assertEquals(result["status_code"], 200)

    # 计费方式格式错误
    def testCreatePayTypeFormatError(self):
        print "testCreatePayTypeFormatError"
        param = {}
        param["Action"] = "CreateInstance"
        param["VPCId"] = Config.get_options("compute", "default_vpcid")
        param["MsubNetId"] = Config.get_options("compute", "default_msub_netid")
        param["ImageId"] = Config.get_options("compute", "default_image_id")
        param["CPU"] = Config.get_options("compute", "default_cpu_count")
        param["Memory"] = Config.get_options("compute", "default_mem_size")
        param["LoginMode"] = Config.get_options("compute", "default_login_mode")
        param["Password"] = Config.get_options("compute", "default_password")
        param["PayType"] = Config.get_options("compute", "pay_type_error")
        param["InstanceName"] = Config.get_options("compute", "instance_name_error")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110033")
        self.assertEquals(result["status_code"], 200)

    # 计费方式方式设计错误
    def testCreatePayTypeTypeError(self):
        print "testCreatePayTypeTypeError"
        param = {}
        param["Action"] = "CreateInstance"
        param["VPCId"] = Config.get_options("compute", "default_vpcid")
        param["MsubNetId"] = Config.get_options("compute", "default_msub_netid")
        param["ImageId"] = Config.get_options("compute", "default_image_id")
        param["CPU"] = Config.get_options("compute", "default_cpu_count")
        param["Memory"] = Config.get_options("compute", "default_mem_size")
        param["LoginMode"] = Config.get_options("compute", "default_login_mode")
        param["Password"] = Config.get_options("compute", "default_password")
        param["PayType"] = Config.get_options("compute", "default_pay_type")
        param["InstanceName"] = Config.get_options("compute", "instance_name_error")
        param["Payduration"] = Config.get_options("compute", "payduration")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110034")
        self.assertEquals(result["status_code"], 200)

    # payduration格式错误
    def testCreatePaydurationError(self):
        print "testCreatePaydurationError"
        param = {}
        param["Action"] = "CreateInstance"
        param["VPCId"] = Config.get_options("compute", "default_vpcid")
        param["MsubNetId"] = Config.get_options("compute", "default_msub_netid")
        param["ImageId"] = Config.get_options("compute", "default_image_id")
        param["CPU"] = Config.get_options("compute", "default_cpu_count")
        param["Memory"] = Config.get_options("compute", "default_mem_size")
        param["LoginMode"] = Config.get_options("compute", "default_login_mode")
        param["Password"] = Config.get_options("compute", "default_password")
        param["PayType"] = Config.get_options("compute", "pay_month")
        param["InstanceName"] = Config.get_options("compute", "instance_name_error")
        param["Payduration"] = Config.get_options("compute", "payduration_error")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110035")
        self.assertEquals(result["status_code"], 200)

    #调用不同的数据中心(返回ak不存在100005)
    def testCreateInstanceDiffData(self):
        print "testCreateInstanceDiffData"
        param = {}
        param["Action"] = "CreateInstance"
        param["VPCId"] = Config.get_options("compute", "beijing_vpcid")
        param["MsubNetId"] = Config.get_options("compute", "beijing_msub_netid")
        param["ImageId"] = Config.get_options("compute", "beijing_image_id")
        param["CPU"] = Config.get_options("compute", "default_cpu_count")
        param["Memory"] = Config.get_options("compute", "default_mem_size")
        param["LoginMode"] = Config.get_options("compute", "default_login_mode")
        param["Password"] = Config.get_options("compute", "default_password")
        param["PayType"] = Config.get_options("compute", "pay_month")
        param["InstanceName"] = Config.get_options("compute", "instance_name_er ror")
        param["Payduration"] = Config.get_options("compute", "default_pay_type")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"3WZ00KN8FG2R8CVTIJ8L","beijing01","")
        param["Signature"] = auth.generator_signatureTwo(param,'4safTa16qwY1BbkedVI68A4jf96MGfa3Mb654N6S')
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)



