#!/usr/bin/env python
# coding: utf-8

from config import Config
from utils import auth, request_utils
import unittest

class ResizeInstanceTest(unittest.TestCase):

  #调整云主机配置（instanceid不存在的云主机）
   def testResizeInstance(self):
        print "testResizeInstance"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        param["InstanceId"] = Config.get_options("resizeInstance", "default_instanceid")
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "default_cpu"))
        param["Memory"] =  request_utils.none_and_null(Config.get_options("resizeInstance", "default_memory"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110043")
        self.assertEquals(result["status_code"], 200)

   #未设置instanceid
   def testResizeInstanceNotSetID(self):
        print "testResizeInstanceNotSetID"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "default_cpu"))
        param["Memory"] = request_utils.none_and_null(Config.get_options("resizeInstance", "default_memory"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110042")
        self.assertEquals(result["status_code"], 200)

   #设置instanceid,但是instanceid为空
   def testResizeInstanceIDIsNull(self):
        print "testResizeInstanceIDIsNull"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_null")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "default_cpu"))
        param["Memory"] = request_utils.none_and_null(Config.get_options("resizeInstance", "default_memory"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110042")
        self.assertEquals(result["status_code"], 200)

   #设置instanceid,但是instanceid格式错误
   def testResizeInstanceIDFormatError(self):
        print "testResizeInstanceIDFormatError"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_format_error")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "default_cpu"))
        param["Memory"] = request_utils.none_and_null(Config.get_options("resizeInstance", "default_memory"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110044")
        self.assertEquals(result["status_code"], 200)

   # 未设置cpu
   def testResizeInstanceCPUNotSet(self):
        print "testResizeInstanceCPUNotSet"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["Memory"] = request_utils.none_and_null(Config.get_options("resizeInstance", "default_memory"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110018")
        self.assertEquals(result["status_code"], 200)

   # cpu为空
   def testResizeInstanceCPUNull(self):
        print "testResizeInstanceCPUNull"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "default_cpu"))
        param["Memory"] = request_utils.none_and_null(
             Config.get_options("resizeInstance", "default_memory"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110054")
        self.assertEquals(result["status_code"], 200)

   # 未设置内存
   def testResizeInstanceMemoryNotSet(self):
        print "testResizeInstanceMemoryNotSet"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "cpu_right"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110018")
        self.assertEquals(result["status_code"], 200)

   # 内存为空
   def testResizeInstanceMemoryNull(self):
        print "testResizeInstanceMemoryNull"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "cpu_right"))
        param["Memory"] = request_utils.none_and_null(
             Config.get_options("resizeInstance", "memory_null"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110054")
        self.assertEquals(result["status_code"], 200)

   # 内存和cpu都未设置
   def testResizeInstanceMemoryAndCPUNotSet(self):
        print "testResizeInstanceMemoryAndCPUNotSet"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110084")
        self.assertEquals(result["status_code"], 200)

   # 内存和cpu都为空
   def testResizeInstanceCpuAndMemoryNull(self):
        print "testResizeInstanceCpuAndMemoryNull"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "default_cpu"))
        param["Memory"] = request_utils.none_and_null(
             Config.get_options("resizeInstance", "memory_null"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110018")
        self.assertEquals(result["status_code"], 200)

   # 内存和cpu为不支持的规格
   def testResizeInstanceFormatError(self):
        print "testResizeInstanceFormatError"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "cpu_error"))
        param["Memory"] = request_utils.none_and_null(
             Config.get_options("resizeInstance", "default_memory"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110018")
        self.assertEquals(result["status_code"], 200)

    # 内存和cpu为的规格大于镜像的最大配置
   def testResizeInstanceFormatBig(self):
        print "testResizeInstanceFormatBig"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "cpu_big"))
        param["Memory"] = request_utils.none_and_null(
             Config.get_options("resizeInstance", "memory_big"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110019")
        self.assertEquals(result["status_code"], 200)

   # 内存和cpu为的规格小于镜像的最小配置
   def testResizeInstanceFormatSmall(self):
        print "testResizeInstanceFormatSmall"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "cpu_small"))
        param["Memory"] = request_utils.none_and_null(
             Config.get_options("resizeInstance", "memory_small"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110020")
        self.assertEquals(result["status_code"], 200)

   # 内存和cpu的格式错误
   def testResizeInstanceFormatDoubleError(self):
        print "testResizeInstanceFormatDoubleError"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "cpu_format_error"))
        param["Memory"] = request_utils.none_and_null(
             Config.get_options("resizeInstance", "memory_format_error"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110054")
        self.assertEquals(result["status_code"], 200)

   # cpu超过配额
   def testResizeCpuExceedingQuota(self):
        print "testResizeCpuExceedingQuota"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "cpu_right"))
        param["Memory"] = request_utils.none_and_null(
             Config.get_options("resizeInstance", "default_memory"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110037")
        # 判断是是否是成功
        if result["data"]["Code"] == "110038":
             print "run ok!"
        self.assertEquals(result["status_code"], 200)

   # 云主机在回收站更改配置
   def testResizeInstanceIsRecyle(self):
        print "testResizeInstanceIsRecyle"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_recycle")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "cpu_right"))
        param["Memory"] = request_utils.none_and_null(
             Config.get_options("resizeInstance", "default_memory"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110069")
        self.assertEquals(result["status_code"], 200)

   # 云主机故障
   def testResizeInstanceIsError(self):
        print "testResizeInstanceIsError"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_error")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "cpu_right"))
        param["Memory"] = request_utils.none_and_null(
             Config.get_options("resizeInstance", "default_memory"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110056")
        self.assertEquals(result["status_code"], 200)

   # 云主机存在续费的订单
   def testResizeInstanceIsRenewing(self):
        print "testResizeInstanceIsRenewing"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_renew")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "cpu_right"))
        param["Memory"] = request_utils.none_and_null(
             Config.get_options("resizeInstance", "default_memory"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110083")
        self.assertEquals(result["status_code"], 200)

   # 账户余额不足
   def testResizeInstanceNotEnough(self):
        print "testResizeInstanceNotEnough"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_renew")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "cpu_right"))
        param["Memory"] = request_utils.none_and_null(
             Config.get_options("resizeInstance", "default_memory"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110075")
        # 判断是是否是成功
        if result["data"]["Code"] == "500001":
             print "run ok!"
        if result["data"]["Code"] == "110056":
             print "run ok!"
        self.assertEquals(result["status_code"], 200)

   # 云主机正在创建自定义镜像
   def testResizeInstanceCreateImage(self):
        print "testResizeInstanceCreateImage"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_renew")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "cpu_right"))
        param["Memory"] = request_utils.none_and_null(
             Config.get_options("resizeInstance", "default_memory"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110082")
        self.assertEquals(result["status_code"], 200)

   # 云主机正在升级再次升级
   def testResizeInstanceUpgrade(self):
        print "testResizeInstanceUpgrade"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_renew")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "cpu_right"))
        param["Memory"] = request_utils.none_and_null(
             Config.get_options("resizeInstance", "default_memory"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110072")
        self.assertEquals(result["status_code"], 200)

   # 云主机升级的规格和当前系统一致
   def testResizeInstanceNoChange(self):
        print "testResizeInstanceNoChange"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "cpu_right"))
        param["Memory"] = request_utils.none_and_null(
             Config.get_options("resizeInstance", "default_memory"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110084")
        self.assertEquals(result["status_code"], 200)

   # 按需计费的云主机余额不足
   def testResizeInstanceEnough(self):
        print "testResizeInstanceEnough"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_enough")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "cpu_right"))
        param["Memory"] = request_utils.none_and_null(
             Config.get_options("resizeInstance", "default_memory"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100017")
        self.assertEquals(result["status_code"], 200)

   # 包年包月的云主机已到期
   def testResizeInstanceIsExpired(self):
        print "testResizeInstanceIsExpired"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_expired")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "cpu_right"))
        param["Memory"] = request_utils.none_and_null(
             Config.get_options("resizeInstance", "default_memory"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100019")
        self.assertEquals(result["status_code"], 200)

   #按需付费的云主机调小
   def testResizeInstanceChangeSmall(self):
        print "testResizeInstanceChangeSmall"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_change_small")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "cpu_right"))
        param["Memory"] = request_utils.none_and_null(
             Config.get_options("resizeInstance", "default_memory"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

   #包年包月的云主机调大
   def testResizeInstanceChangeBig(self):
        print "testResizeInstanceChangeBig"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_change_big")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "cpu_right"))
        param["Memory"] = request_utils.none_and_null(
             Config.get_options("resizeInstance", "default_memory"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

   #包年包月的云主机调小
   def testResizeInstanceExpiredChangeSmall(self):
        print "testResizeInstanceExpiredChangeSmall"
        # 拼接数据
        param = {}
        param["Action"] = "ResizeInstance"
        instanceId = Config.get_options("resizeInstance", "instanceid_change_big")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["CPU"] = request_utils.none_and_null(Config.get_options("resizeInstance", "cpu_change_small"))
        param["Memory"] = request_utils.none_and_null(
             Config.get_options("resizeInstance", "memory_change_small"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110055")
        self.assertEquals(result["status_code"], 200)
