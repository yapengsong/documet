#!/usr/bin/env python
# coding: utf-8

from config import Config
from utils import auth, request_utils
import unittest

class DescribeInstancesTest(unittest.TestCase):

    # 查询云主机(ok)
    def testDescribeInstances(self):
        print "testDescribeInstances****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        instanceIds = Config.get_options("describeInstances", "default_instance_ids")
        param["InstanceIds"] = request_utils.array_filter_null(instanceIds.split(","))
        imageIdsVar = Config.get_options("describeInstances", "default_image_ids")
        param["ImageIds"] = request_utils.array_filter_null(imageIdsVar.split(","))
        searchWord = Config.get_options("describeInstances", "default_searchword")
        param["SearchWord"] = request_utils.none_and_null(searchWord)
        param["Status"] = Config.get_options("describeInstances", "default_status")
        ip = Config.get_options("describeInstances", "default_ip")
        param["IP"] = request_utils.none_and_null(ip)
        param["Offset"] = Config.get_options("describeInstances", "default_offset")
        param["Limit"] = Config.get_options("describeInstances", "default_limit")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机(所有的参数都未设置)
    def testDescribeInstancesNoParameter(self):
        print "testDescribeInstancesNoParameter****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机(所有的参数都为空)
    def testDescribeInstancesAllParameterNull(self):
        print "testDescribeInstancesAllParameterNull****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        instanceIds = Config.get_options("describeInstances", "default_instance_ids")
        param["InstanceIds"] = []
        param["ImageIds"] = []
        param["SearchWord"] = ''
        param["Status"] = ''
        param["IP"] = ''
        param["Offset"] = ''
        param["Limit"] = ''
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机(SearchWord参数格式错误)
    def testSearchWordFormatError(self):
        print "testSearchWordFormatError****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        searchWord = Config.get_options("describeInstances", "searchword_format_error")
        param["SearchWord"] = searchWord
        if ('null' == searchWord):
            param["SearchWord"] = ''
        param["Offset"] = Config.get_options("describeInstances", "default_offset")
        param["Limit"] = Config.get_options("describeInstances", "default_limit")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100023")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机(SearchWord模糊查询)
    def testSearchWordDimSearch(self):
        print "testSearchWordDimSearch****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        searchWord = Config.get_options("describeInstances", "searchword_dim")
        param["SearchWord"] = request_utils.none_and_null(searchWord)
        param["Offset"] = Config.get_options("describeInstances", "default_offset")
        param["Limit"] = Config.get_options("describeInstances", "default_limit")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机(未设置SearchWord字段)
    def testSearchWordNotSet(self):
        print "testSearchWordNotSet****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        param["Offset"] = Config.get_options("describeInstances", "default_offset")
        param["Limit"] = Config.get_options("describeInstances", "default_limit")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机(偏移量不合法)
    def testOffsetFormatError(self):
        print "testOffsetFormatError****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        param["Offset"] = Config.get_options("describeInstances", "offset_format_error")
        param["Limit"] = Config.get_options("describeInstances", "default_limit")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100026")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机(limit不合法)
    def testLimitFormatError(self):
        print "testLimitFormatError****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        param["Offset"] = Config.get_options("describeInstances", "default_offset")
        param["Limit"] = Config.get_options("describeInstances", "limit_fromat_error")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100027")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机(limit和offset不设置)
    def testLimitAndOffsetNotSet(self):
        print "testLimitAndOffsetNotSet****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机(instanceid不存在)
    def testInstanceidNotExit(self):
        print "testInstanceidNotExit****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        instanceIds = Config.get_options("describeInstances", "instanceids_notexit")
        param["InstanceIds"] = instanceIds.split(",")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110043")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机(instanceid数组中有一个不存在)
    def testInstanceidsHaveOneNotExit(self):
        print "testInstanceidsHaveOneNotExit****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        instanceIds = Config.get_options("describeInstances", "instanceids_notexit_many")
        param["InstanceIds"] = instanceIds.split(",")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110043")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机(instanceid格式错误)
    def testDescribeInstanceidsFormatError(self):
        print "testDescribeInstanceidsFormatError****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        instanceIds = Config.get_options("describeInstances", "instanceids_format_error")
        param["InstanceIds"] = instanceIds.split(",")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110044")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机(instanceid录入21个)
    def testInstanceidsFormatErrorTwo(self):
        print "testInstanceidsFormatErrorTwo****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        instanceIds = Config.get_options("describeInstances", "instanceids_format_error_21")
        param["InstanceIds"] = instanceIds.split(",")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110044")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机(instanceid录入20个)
    def testInstanceidsResult(self):
        print "testInstanceidsResult****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        instanceIds = Config.get_options("describeInstances", "instanceids_format_error_20")
        param["InstanceIds"] = instanceIds.split(",")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机(ImageIds不存在)
    def testImageIdsNotExit(self):
        print "testImageIdsNotExit****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        instanceIds = Config.get_options("describeInstances", "default_instance_ids").split(",")
        param["InstanceIds"] = request_utils.array_filter_null(instanceIds)
        param["ImageIds"] = Config.get_options("describeInstances", "imageid_notexit").split(",")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110016")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机(ImageIds数组中有一个不存在)
    def testImageIdsOneNotExit(self):
        print "testImageIdsOneNotExit****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        instanceIds = Config.get_options("describeInstances", "default_instance_ids")
        param["InstanceIds"] = instanceIds.split(",")
        param["ImageIds"] = Config.get_options("describeInstances", "imageid_one_notexit").split(",")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110016")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机(ImageIds格式不正确)
    def testDescribeImageIdsFormatError(self):
        print "testDescribeImageIdsFormatError****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        instanceIds = Config.get_options("describeInstances", "default_instance_ids")
        param["InstanceIds"] = instanceIds.split(",")
        param["ImageIds"] = Config.get_options("describeInstances", "imageids_format_error").split(",")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110017")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机(ImageIds21个)
    def testImageIdsFormatErrorTwo(self):
        print "testImageIdsFormatErrorTwo****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        instanceIds = Config.get_options("describeInstances", "default_instance_ids")
        param["InstanceIds"] = instanceIds.split(",")
        param["ImageIds"] = Config.get_options("describeInstances", "imageids_format_error_21").split(",")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110017")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机(ImageIds20个)
    def testImageIdsResult(self):
        print "testImageIdsResult****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        instanceIds = Config.get_options("describeInstances", "default_instance_ids")
        param["InstanceIds"] = instanceIds.split(",")
        param["ImageIds"] = Config.get_options("describeInstances", "imageids_format_error_20").split(",")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机(主机的状态不合法)
    def testStatusFormatError(self):
        print "testStatusFormatError****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        instanceIds = Config.get_options("describeInstances", "default_instance_ids")
        param["InstanceIds"] = instanceIds.split(",")
        param["ImageIds"] = Config.get_options("describeInstances", "imageids_format_error_20").split(",")
        param["Status"] = Config.get_options("describeInstances", "status_error")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110045")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机（主机的状态设置为空）
    def testStatusNull(self):
        print "testStatusNull****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        instanceIds = Config.get_options("describeInstances", "default_instance_ids")
        param["InstanceIds"] = instanceIds.split(",")
        param["ImageIds"] = Config.get_options("describeInstances", "imageids_format_error_20").split(",")
        param["Status"] = ''
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机（主机的状态未设置，ip未设置）
    def testStatusNotSet(self):
        print "testStatusNotSet****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        instanceIds = Config.get_options("describeInstances", "default_instance_ids")
        param["InstanceIds"] = instanceIds.split(",")
        param["ImageIds"] = Config.get_options("describeInstances", "imageids_format_error_20").split(",")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机（IP格式错误）
    def testIpFormatError(self):
        print "testIpFormatError****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        instanceIds = Config.get_options("describeInstances", "default_instance_ids")
        param["InstanceIds"] = instanceIds.split(",")
        param["ImageIds"] = Config.get_options("describeInstances", "default_image_ids").split(",")
        param["IP"] = Config.get_options("describeInstances", "ip_error")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110046")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机（IP不存在,的时候提示未找到相关结果100025）
    def testIpNotExit(self):
        print "testIpNotExit****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        instanceIds = Config.get_options("describeInstances", "default_instance_ids")
        param["InstanceIds"] = instanceIds.split(",")
        param["ImageIds"] = Config.get_options("describeInstances", "default_image_ids").split(",")
        param["IP"] = Config.get_options("describeInstances", "ip_not_exit")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110047")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机（IP为空）
    def testIpNull(self):
        print "testIpNull****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        instanceIds = Config.get_options("describeInstances", "default_instance_ids")
        param["InstanceIds"] = instanceIds.split(",")
        param["ImageIds"] = Config.get_options("describeInstances", "default_image_ids").split(",")
        param["IP"] = request_utils.none_and_null(Config.get_options("describeInstances", "ip_null"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机（未找到相关查询结果）
    def testStatusResultNull(self):
        print "testStatusResultNull****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        instanceIds = Config.get_options("describeInstances", "default_instance_ids")
        param["InstanceIds"] = instanceIds.split(",")
        param["ImageIds"] = Config.get_options("describeInstances", "default_image_ids").split(",")
        param["Status"] = 'ERROR'
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100025")
        self.assertEquals(result["status_code"], 200)

    # 查询云主机（模糊查询或者未找到相关结果）
    def testStatusResultLike(self):
        print "testStatusResultLike****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        instanceIds = Config.get_options("describeInstances", "default_instance_ids")
        param["InstanceIds"] = instanceIds.split(",")
        param["ImageIds"] = Config.get_options("describeInstances", "default_image_ids").split(",")
        param["IP"] = Config.get_options("describeInstances", "ip_like")
       # param["Status"] = Config.get_options("describeInstances", "default_status")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100025")
        # 判断是是否是成功
        if result["data"]["Code"] == "0":
            print "run ok!"
        self.assertEquals(result["status_code"], 200)

    # 查询云主机（limit实际的值大于设置的值，只能展示到设置的值）
    def testStatusLimitSmall(self):
        print "testStatusLimitSmall****************"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        param["Limit"] = Config.get_options("describeInstances", "limit_small")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        # 判断是是否是成功
        if result["data"]["Code"] == "100025":
            print "run ok!"
        self.assertEquals(result["status_code"], 200)

    # 查询云主机（云主机id和镜像id都为多个）
    def testInstanceidAndImagids(self):
        print "testInstanceidAndImagids"
        # 拼接数据
        param = {}
        param["Action"] = "DescribeInstances"
        param["InstanceIds"] = Config.get_options("describeInstances", "default_instance_ids").split(",")
        param["ImageIds"] = Config.get_options("describeInstances", "imageids_format_error_20").split(",")
        param["Limit"] = Config.get_options("describeInstances", "default_limit")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        # 判断是是否是成功
        if result["data"]["Code"] == "100025":
            print "run ok!"
        self.assertEquals(result["status_code"], 200)



