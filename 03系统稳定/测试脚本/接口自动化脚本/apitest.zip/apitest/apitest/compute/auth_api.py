#!/usr/bin/env python
# coding: utf-8

from config import Config
from utils import auth, request_utils
import unittest
import datetime

class AuthTest(unittest.TestCase):
    def setUp(self):
        Config.init_config()

    def tearDown(self):
        pass
    # 创建云主机-未设置action(不录入action参数或者参数为空都是可以的)
    def testAuth_action(self):
        print "testAuth_action"
        param = {}
        param = request_utils.generator_compute(param)
        param["Action"] = ""
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100002")
        self.assertEquals(result["status_code"], 200)

    # 创建云主机-设置的action为不存在的action
    def testCreateInstance_errorAction(self):
        print "testCreateInstance-errorAction"
        param = {}
        param = request_utils.generator_compute(param)
        param["Action"] = "testCreateInstance"
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100004")
        self.assertEquals(result["status_code"], 200)

    # 创建云主机-设置AccessKey和SK为空
    def testCreateInstance_nullAkAndSk(self):
        print "testCreateInstance_nullAkAndSk"
        param = {}
        param = request_utils.generator_compute(param)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,None,"","")
        param["Signature"] = auth.generator_signatureTwo(param,"no")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100003")
        self.assertEquals(result["status_code"], 200)

    #设置AccessKey为不存在的值
    def testCreateInstance_noExistAkAndSk(self):
        print "testCreateInstance_noExistAkAndSk"
        param = {}
        param = request_utils.generator_compute(param)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,'123456789',"","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100005")
        self.assertEquals(result["status_code"], 200)

    # 创建云主机-Signature不匹配
    def testCreateInstance_signature(self):
        print "testCreateInstance_signature"
        param = {}
        param = request_utils.generator_compute(param)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = "123456789"
        # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100010")
        self.assertEquals(result["status_code"], 200)

    # 创建云主机-Signature未设置
    def testCreateInstance_Nosignature(self):
        print "testCreateInstance_Nosignature"
        param = {}
        param = request_utils.generator_compute(param)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100011")
        self.assertEquals(result["status_code"], 200)

    # 创建云主机-Signature格式错误
    def testCreateInstance_signatureFormatError(self):
        print "testCreateInstance_signatureFormatError"
        param = {}
        param = request_utils.generator_compute(param)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = ["123456789"]
        # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100012")
        self.assertEquals(result["status_code"], 200)

    # 创建云主机-Signature超时
    def testCreateInstance_signatureTimeOut(self):
        print "testCreateInstance_signatureTimeOut"
        param = {}
        param = request_utils.generator_compute(param)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","2017-02-22T08:35:35Z")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100013")
        self.assertEquals(result["status_code"], 200)

    # 创建云主机-未设置Timestamp
    def testCreateInstance_NoTimestamp(self):
        print "testCreateInstance_NoTimestamp"
        param = {}
        param = request_utils.generator_compute(param)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", None)
        param["Signature"] = auth.generator_signatureTwo(param,"")
        # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100014")
        self.assertEquals(result["status_code"], 200)

    # 创建云主机-Timestamp无效
    def testCreateInstance_TimestampVoid(self):
        print "testCreateInstance_TimestampVoid"
        param = {}
        param = request_utils.generator_compute(param)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "2017-02-22 08:35:35Z")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100015")
        self.assertEquals(result["status_code"], 200)

    # body为空或者为null
    def testCreateInstance_bodyNull(self):
        print "testCreateInstance_bodyNull"
        param = {}  # 或者body为null
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100032")
        self.assertEquals(result["status_code"], 200)

    # 数据中心不存在
    def testCreateInstance_regionNotExist(self):
        print "testCreateInstance_regionNotExist"
        param = {}
        param = request_utils.generator_compute(param)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "meiguo", "")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100020")
        self.assertEquals(result["status_code"], 200)

    # 数据中心格式不合法
    def testCreateInstance_regionFormatError(self):
        print "testCreateInstance_regionFormatError"
        param = {}
        param = request_utils.generator_compute(param)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "_beijing02", "")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100021")
        self.assertEquals(result["status_code"], 200)

    # 数据中心参数未设置
    def testCreateInstance_noRegion(self):
        print "testCreateInstance_noRegion"
        param = {}
        param = request_utils.generator_compute(param)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", None, "")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100022")
        self.assertEquals(result["status_code"], 200)

    # 数据中心下无项目
    def testCreateInstance_regionNoPro(self):
        print "testCreateInstance_regionNoPro"
        param = {}
        param = request_utils.generator_compute(param)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "beijing03", "")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100030")
        self.assertEquals(result["status_code"], 200)

    # 请求头中的参数格式错误或者为空
    def testCreateInstance_headFormatError(self):
        print "testCreateInstance_headFormatError"
        param = {}
        param = request_utils.generator_compute(param)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        # print param
        # 拼装返回的结果
        result = request_utils.request_post(param,"","100028")
        # 断言查看结果是否正确
        self.assertEquals(result["status_code"], 200)



