#!/usr/bin/env python
# coding: utf-8

from config import Config
from utils import auth, request_utils
import unittest
class InstanceAndSecurityGroupTest(unittest.TestCase):

    # 未设置instanceid
    def testJoinGroupNotSetID(self):
        print "testJoinGroupNotSetID"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceJoinSecurityGroup"
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("joinSecurityGroup", "default_group_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110042")
        self.assertEquals(result["status_code"], 200)

    # instanceid已经删除
    def testJoinGroupIdDeleted(self):
        print "testJoinGroupIdDeleted"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceJoinSecurityGroup"
        param["InstanceId"] = Config.get_options("joinSecurityGroup", "default_instanceid")
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("joinSecurityGroup", "default_group_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110043")
        self.assertEquals(result["status_code"], 200)

    # instanceid为空
    def testJoinGroupIdNull(self):
        print "testJoinGroupIdNull"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceJoinSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(Config.get_options("joinSecurityGroup", "instance_id_null"))
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("joinSecurityGroup", "default_group_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110042")
        self.assertEquals(result["status_code"], 200)

    # instanceid格式错误
    def testJoinGroupIdFormatError(self):
        print "testJoinGroupIdFormatError"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceJoinSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(Config.get_options("joinSecurityGroup", "instance_id_error"))
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("joinSecurityGroup", "default_group_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110044")
        self.assertEquals(result["status_code"], 200)

    # SecurityGroupId格式错误
    def testJoinGroupGroupIdFormatError(self):
        print "testJoinGroupGroupIdFormatError"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceJoinSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(Config.get_options("joinSecurityGroup", "instance_id_right"))
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("joinSecurityGroup", "group_id_error"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110066")
        self.assertEquals(result["status_code"], 200)

    # SecurityGroupId未设置
    def testJoinGroupGroupIdNotSet(self):
        print "testJoinGroupGroupIdNotSet"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceJoinSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(Config.get_options("joinSecurityGroup", "instance_id_right"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110064")
        self.assertEquals(result["status_code"], 200)

    # SecurityGroupId为空
    def testJoinGroupGroupIdNull(self):
        print "testJoinGroupGroupIdNull"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceJoinSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(
            Config.get_options("joinSecurityGroup", "instance_id_right"))
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("joinSecurityGroup", "group_id_null"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110064")
        self.assertEquals(result["status_code"], 200)

    # SecurityGroupId不存在
    def testJoinGroupGroupIdNotExit(self):
        print "testJoinGroupGroupIdNotExit"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceJoinSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(Config.get_options("joinSecurityGroup", "instance_id_right"))
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("joinSecurityGroup", "group_id_notexit"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110065")
        self.assertEquals(result["status_code"], 200)

     # 云主机已在安全组SecurityGroupId下
    def testJoinGroupGroupIdExit(self):
        print "testJoinGroupGroupIdExit"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceJoinSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(Config.get_options("joinSecurityGroup", "instance_id_exit"))
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("joinSecurityGroup", "default_group_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110067")
        self.assertEquals(result["status_code"], 200)

    # 云主机和安全组不属于同一个项目
    def testJoinGroupGroupIdDiffPro(self):
        print "testJoinGroupGroupIdDiffPro"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceJoinSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(Config.get_options("joinSecurityGroup", "instance_id_right"))
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("joinSecurityGroup", "group_id_other"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110065")
        self.assertEquals(result["status_code"], 200)

    # 云主机在回收站
    def testJoinGroupInstanceRecycle(self):
        print "testJoinGroupInstanceRecycle"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceJoinSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(Config.get_options("modifyInstance", "instance_syscle"))
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("joinSecurityGroup", "default_group_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110070")
        self.assertEquals(result["status_code"], 200)

    # 云主机故障或者暂停服务
    def testJoinGroupInstanceError(self):
        print "testJoinGroupInstanceError"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceJoinSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(Config.get_options("modifyInstance", "instanceid_error"))
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("joinSecurityGroup", "default_group_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 云主机加入安全组成功
    def testJoinGroupSuccess(self):
        print "testJoinGroupSuccess"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceJoinSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(Config.get_options("joinSecurityGroup", "instance_id_right"))
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("joinSecurityGroup", "default_group_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 云主机余额不足
    def testJoinGroupInstanceEnough(self):
        print "testJoinGroupInstanceEnough"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceJoinSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(Config.get_options("joinSecurityGroup", "instance_id_right"))
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("joinSecurityGroup", "default_group_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100017")
        self.assertEquals(result["status_code"], 200)

    # 云主机已到期
    def testJoinGroupInstanceExpired(self):
        print "testJoinGroupInstanceExpired"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceJoinSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(Config.get_options("joinSecurityGroup", "instance_id_expired"))
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("joinSecurityGroup", "default_group_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100019")
        self.assertEquals(result["status_code"], 200)

     # 未设置instanceid
    def testLeaveGroupNotSetID(self):
        print "testLeaveGroupNotSetID"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceLeaveSecurityGroup"
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("leaveSecurityGroup", "default_group_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110042")
        self.assertEquals(result["status_code"], 200)

    # instanceid已经删除
    def testLeaveGroupIdDeleted(self):
        print "testLeaveGroupIdDeleted"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceLeaveSecurityGroup"
        param["InstanceId"] = Config.get_options("leaveSecurityGroup", "default_instanceid")
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("leaveSecurityGroup", "default_group_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110043")
        self.assertEquals(result["status_code"], 200)

    # instanceid为空
    def testLeaveGroupIdNull(self):
        print "testLeaveGroupIdNull"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceLeaveSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(Config.get_options("leaveSecurityGroup", "instance_id_null"))
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("leaveSecurityGroup", "default_group_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110042")
        self.assertEquals(result["status_code"], 200)

    # instanceid格式错误
    def testLeaveGroupIdFormatError(self):
        print "testLeaveGroupIdFormatError"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceLeaveSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(Config.get_options("leaveSecurityGroup", "instance_id_error"))
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("leaveSecurityGroup", "default_group_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110044")
        self.assertEquals(result["status_code"], 200)

     # SecurityGroupId格式错误
    def testLeaveGroupGroupIdFormatError(self):
        print "testLeaveGroupGroupIdFormatError"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceLeaveSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(Config.get_options("leaveSecurityGroup", "instance_id_right"))
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("leaveSecurityGroup", "group_id_error"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110066")
        self.assertEquals(result["status_code"], 200)

    # SecurityGroupId未设置
    def testLeaveGroupGroupIdNotSet(self):
        print "testLeaveGroupGroupIdNotSet"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceLeaveSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(Config.get_options("leaveSecurityGroup", "instance_id_right"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110064")
        self.assertEquals(result["status_code"], 200)

    # SecurityGroupId为空
    def testLeaveGroupGroupIdNull(self):
        print "testLeaveGroupGroupIdNull"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceLeaveSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(
            Config.get_options("leaveSecurityGroup", "instance_id_right"))
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("leaveSecurityGroup", "group_id_null"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110064")
        self.assertEquals(result["status_code"], 200)

    # SecurityGroupId不存在
    def testLeaveGroupGroupIdNotExit(self):
        print "testLeaveGroupGroupIdNotExit"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceLeaveSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(Config.get_options("leaveSecurityGroup", "instance_id_right"))
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("leaveSecurityGroup", "group_id_notexit"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110065")
        self.assertEquals(result["status_code"], 200)

    # 云主机和安全组不属于同一个项目
    def testLeaveGroupGroupIdDiffPro(self):
        print "testLeaveGroupGroupIdDiffPro"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceLeaveSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(
            Config.get_options("leaveSecurityGroup", "instance_id_right"))
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("leaveSecurityGroup", "group_id_other"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110068")
        self.assertEquals(result["status_code"], 200)

    # 云主机在回收站
    def testLeaveGroupInstanceRecycle(self):
        print "testLeaveGroupInstanceRecycle"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceLeaveSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(Config.get_options("modifyInstance", "instance_syscle"))
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("leaveSecurityGroup", "default_group_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110071")
        # 判断是是否是成功
        if result["data"]["Code"] == "":
            print "run ok!"
        self.assertEquals(result["status_code"], 200)

    # 云主机故障或者暂停服务
    def testLeaveGroupInstanceError(self):
        print "testLeaveGroupInstanceError"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceLeaveSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(Config.get_options("modifyInstance", "instanceid_error"))
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("leaveSecurityGroup", "default_group_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 云主机离开安全组成功
    def testInstanceLeaveGroupSuccess(self):
        print "testInstanceLeaveGroupSuccess"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceLeaveSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(Config.get_options("leaveSecurityGroup", "instance_id_exit"))
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("leaveSecurityGroup", "default_group_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

    # 云主机余额不足
    def testLeaveGroupInstanceEnough(self):
        print "testLeaveGroupInstanceEnough"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceLeaveSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(Config.get_options("leaveSecurityGroup", "instance_id_right"))
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("leaveSecurityGroup", "default_group_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100017")
        self.assertEquals(result["status_code"], 200)

    # 云主机已到期
    def testLeaveGroupInstanceExpired(self):
        print "testLeaveGroupInstanceExpired"
        # 拼接数据
        param = {}
        param["Action"] = "InstanceLeaveSecurityGroup"
        param["InstanceId"] = request_utils.none_and_null(Config.get_options("leaveSecurityGroup", "instance_id_expired"))
        param["SecurityGroupId"] = request_utils.none_and_null(
            Config.get_options("leaveSecurityGroup", "default_group_id"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100019")
        self.assertEquals(result["status_code"], 200)