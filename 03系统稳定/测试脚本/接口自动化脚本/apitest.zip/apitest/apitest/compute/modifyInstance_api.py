#!/usr/bin/env python
# coding: utf-8

from config import Config
from utils import auth, request_utils
import unittest

class ModifyInstanceTest(unittest.TestCase):

  #修改云主机信息（instanceid不存在的云主机）
   def testModifyInstance(self):
        print "testModifyInstance"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstance"
        param["InstanceId"] = Config.get_options("modifyInstance", "default_instanceid")
        param["InstanceName"] = request_utils.none_and_null(Config.get_options("modifyInstance", "default_instance_name"))
        param["InstanceRemark"] =  request_utils.none_and_null(Config.get_options("modifyInstance", "default_instance_remark"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110043")
        self.assertEquals(result["status_code"], 200)

   #未设置instanceid
   def testInstanceNotSetID(self):
        print "testInstanceNotSetID"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstance"
        param["InstanceName"] = request_utils.none_and_null(Config.get_options("modifyInstance", "default_instance_name"))
        param["InstanceRemark"] = request_utils.none_and_null(Config.get_options("modifyInstance", "default_instance_remark"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110042")
        self.assertEquals(result["status_code"], 200)

   #设置instanceid,但是instanceid为空
   def testInstanceIDIsNull(self):
        print "testInstanceIDIsNull"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstance"
        instanceId = Config.get_options("modifyInstance", "instanceid_null")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["InstanceName"] = request_utils.none_and_null(Config.get_options("modifyInstance", "default_instance_name"))
        param["InstanceRemark"] = request_utils.none_and_null(Config.get_options("modifyInstance", "default_instance_remark"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110042")
        self.assertEquals(result["status_code"], 200)

   #设置instanceid,但是instanceid格式错误
   def testInstanceIDFormatError(self):
        print "testInstanceIDFormatError"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstance"
        instanceId = Config.get_options("modifyInstance", "instanceid_format_error")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["InstanceName"] = request_utils.none_and_null(Config.get_options("modifyInstance", "default_instance_name"))
        param["InstanceRemark"] = request_utils.none_and_null(Config.get_options("modifyInstance", "default_instance_remark"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110044")
        self.assertEquals(result["status_code"], 200)

   # 未设置InstanceName
   def testNameNotSet(self):
        print "testNameNotSet"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstance"
        instanceId = Config.get_options("modifyInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["InstanceRemark"] = request_utils.none_and_null(Config.get_options("modifyInstance", "default_instance_remark"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

   # InstanceName为空
   def testNameIsNull(self):
        print "testNameIsNull"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstance"
        instanceId = Config.get_options("modifyInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["InstanceName"] = request_utils.none_and_null(Config.get_options("modifyInstance", "name_null"))
        param["InstanceRemark"] = request_utils.none_and_null(
             Config.get_options("modifyInstance", "default_instance_remark"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110027")
        self.assertEquals(result["status_code"], 200)

   # InstanceName格式错误
   def testNameFormatError(self):
        print "testNameFormatError"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstance"
        instanceId = Config.get_options("modifyInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["InstanceName"] = request_utils.none_and_null(Config.get_options("modifyInstance", "name_format_error"))
        param["InstanceRemark"] = request_utils.none_and_null(
             Config.get_options("modifyInstance", "default_instance_remark"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110028")
        self.assertEquals(result["status_code"], 200)

   # InstanceName名称已存在
   def testNameIsExit(self):
        print "testNameIsExit"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstance"
        instanceId = Config.get_options("modifyInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["InstanceName"] = request_utils.none_and_null(
             Config.get_options("modifyInstance", "name_exit"))
        param["InstanceRemark"] = request_utils.none_and_null(
             Config.get_options("modifyInstance", "default_instance_remark"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110029")
        self.assertEquals(result["status_code"], 200)

  # 未设置InstanceRemark
   def testInstanceRemarkNotSet(self):
        print "testInstanceRemarkNotSet"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstance"
        instanceId = Config.get_options("modifyInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["InstanceName"] = request_utils.none_and_null(Config.get_options("modifyInstance", "default_instance_name"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

   # 设置InstanceRemark为空
   def testInstanceRemarkIsNull(self):
        print "testInstanceRemarkIsNull"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstance"
        instanceId = Config.get_options("modifyInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["InstanceName"] = request_utils.none_and_null(Config.get_options("modifyInstance", "instance_name"))
        param["InstanceRemark"] = request_utils.none_and_null(
             Config.get_options("modifyInstance", "remark_null"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

   # 设置InstanceRemark格式错误
   def testRemarkFormatError(self):
        print "testRemarkFormatError"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstance"
        instanceId = Config.get_options("modifyInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["InstanceName"] = request_utils.none_and_null(Config.get_options("modifyInstance", "instance_name"))
        param["InstanceRemark"] = request_utils.none_and_null(
             Config.get_options("modifyInstance", "remark_format_error"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110030")
        self.assertEquals(result["status_code"], 200)

   # 设置InstanceRemark格式错误
   def testInstanceToIsRecycle(self):
        print "testInstanceToIsRecycle"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstance"
        instanceId = Config.get_options("modifyInstance", "instance_syscle")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["InstanceName"] = request_utils.none_and_null(
             Config.get_options("modifyInstance", "instance_name"))
        param["InstanceRemark"] = request_utils.none_and_null(
             Config.get_options("modifyInstance", "remark_null"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110069")
        self.assertEquals(result["status_code"], 200)

    # 设置InstanceRemark和名称的最大值修改
   def testInstanceRemarkAndNameBig(self):
        print "testInstanceRemarkAndNameBig"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstance"
        instanceId = Config.get_options("modifyInstance", "instance_id_enough")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["InstanceName"] = request_utils.none_and_null(
             Config.get_options("modifyInstance", "instance_name_big"))
        param["InstanceRemark"] = request_utils.none_and_null(
             Config.get_options("modifyInstance", "remark_big"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"0")
        self.assertEquals(result["status_code"], 200)

   # InstanceRemark和名称都未设置
   def testInstanceRemarkAndNameNotSet(self):
        print "testInstanceRemarkAndNameNotSet"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstance"
        instanceId = Config.get_options("modifyInstance", "instance_id_enough")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110087")
        self.assertEquals(result["status_code"], 200)

   # InstanceRemark和名称都为空
   def testInstanceRemarkAndNameNull(self):
        print "testInstanceRemarkAndNameNull"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstance"
        instanceId = Config.get_options("modifyInstance", "instance_id_enough")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["InstanceName"] = request_utils.none_and_null(
             Config.get_options("modifyInstance", "name_null"))
        param["InstanceRemark"] = request_utils.none_and_null(
             Config.get_options("modifyInstance", "remark_null"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110027")
        self.assertEquals(result["status_code"], 200)

   # 云主机暂停服务或者故障
   def testModifyInstanceIsError(self):
        print "testModifyInstanceIsError"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstance"
        instanceId = Config.get_options("modifyInstance", "instanceid_error")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["InstanceName"] = request_utils.none_and_null(Config.get_options("modifyInstance", "instance_name"))
        param["InstanceRemark"] = request_utils.none_and_null(
             Config.get_options("modifyInstance", "remark_null"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110081")
        self.assertEquals(result["status_code"], 200)

   # 按需计费的云主机余额不足
   def testInstanceEnough(self):
        print "testInstanceEnough"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstance"
        instanceId = Config.get_options("modifyInstance", "instance_id_enough")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["InstanceName"] = request_utils.none_and_null(Config.get_options("modifyInstance", "instance_name"))
        param["InstanceRemark"] = request_utils.none_and_null(
             Config.get_options("modifyInstance", "default_instance_remark"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100017")
        self.assertEquals(result["status_code"], 200)


   # 包年包月的云主机已到期
   def testInstanceIsExpired(self):
        print "testInstanceIsExpired"
        # 拼接数据
        param = {}
        param["Action"] = "ModifyInstance"
        instanceId = Config.get_options("modifyInstance", "instance_id_expired")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        param["InstanceName"] = request_utils.none_and_null(Config.get_options("modifyInstance", "instance_name"))
        param["InstanceRemark"] = request_utils.none_and_null(
             Config.get_options("modifyInstance", "default_instance_remark"))
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param,"","","")
        param["Signature"] = auth.generator_signatureTwo(param,"")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100019")
        self.assertEquals(result["status_code"], 200)
