#!/usr/bin/env python
# coding: utf-8

from config import Config
from utils import auth, request_utils
import unittest

class RebootInstanceTest(unittest.TestCase):

  #关闭一个instanceid不存在的云主机
   def testRebootInstance(self):
        print "testRebootInstance"
        # 拼接数据
        param = {}
        param["Action"] = "RebootInstance"
        param["InstanceId"] = Config.get_options("rebootInstance", "default_instanceid")
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110043")
        self.assertEquals(result["status_code"], 200)

   #未设置instanceid
   def testRebootInstanceNotSetID(self):
        print "testRebootInstanceNotSetID"
        # 拼接数据
        param = {}
        param["Action"] = "RebootInstance"
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110042")
        self.assertEquals(result["status_code"], 200)

   #设置instanceid,但是instanceid为空
   def testRebootInstanceIDIsNull(self):
        print "testRebootInstanceIDIsNull"
        # 拼接数据
        param = {}
        param["Action"] = "RebootInstance"
        instanceId = Config.get_options("rebootInstance", "instanceid_null")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110042")
        self.assertEquals(result["status_code"], 200)

   #设置instanceid,但是instanceid格式错误
   def testRebootInstanceIDFormatError(self):
        print "testRebootInstanceIDFormatError"
        # 拼接数据
        param = {}
        param["Action"] = "RebootInstance"
        instanceId = Config.get_options("rebootInstance", "instanceid_format_error")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110044")
        self.assertEquals(result["status_code"], 200)

   #设置instanceid,云主机为关闭状态
   def testRebootInstanceShutOff(self):
        print "testRebootInstanceShutOff"
        # 拼接数据
        param = {}
        param["Action"] = "RebootInstance"
        instanceId = Config.get_options("rebootInstance", "instanceid_shutoff")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110048")
        self.assertEquals(result["status_code"], 200)

   # 云主机正在创建自定义镜像
   def testRebootInstanceCreateImage(self):
        print "testRebootInstanceCreateImage"
        # 拼接数据
        param = {}
        param["Action"] = "RebootInstance"
        instanceId = Config.get_options("rebootInstance", "instanceid_right")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110049")
        self.assertEquals(result["status_code"], 200)

   # 云主机故障
   def testRebootInstanceError(self):
        print "testRebootInstanceError"
        # 拼接数据
        param = {}
        param["Action"] = "RebootInstance"
        instanceId = Config.get_options("rebootInstance", "instanceid_error")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"110048")
        self.assertEquals(result["status_code"], 200)

   # 云主机已到期
   def testRebootInstanceExpired(self):
        print "testRebootInstanceExpired"
        # 拼接数据
        param = {}
        param["Action"] = "RebootInstance"
        instanceId = Config.get_options("rebootInstance", "instanceid_expired")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100019")
        self.assertEquals(result["status_code"], 200)

   # 云主机余额不足
   def testRebootInstanceNotEnough(self):
        print "testRebootInstanceNotEnough"
        # 拼接数据
        param = {}
        param["Action"] = "RebootInstance"
        instanceId = Config.get_options("rebootInstance", "instanceid_not_enough")
        param["InstanceId"] = request_utils.none_and_null(instanceId)
        # 添加公共的参数和signature
        param = request_utils.generator_common_paramTwo(param, "", "", "")
        param["Signature"] = auth.generator_signatureTwo(param, "")
        print param
        # 拼装返回的结果
        result = request_utils.request_post(param,None,"100017")
        self.assertEquals(result["status_code"], 200)