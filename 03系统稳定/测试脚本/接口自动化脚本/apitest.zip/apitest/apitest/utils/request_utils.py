#!/usr/bin/env python
# coding: utf-8
from config import Config
import datetime
import requests
import json
import time
import pytz
# 获取公共参数
# def generator_common_param(request_param):
#     if not request_param:
#         request_param = {}
#     # 数据中心编号
#     request_param["Region"] = Config.get_options("api", "default_regin")
#     # AK
#     request_param["AccessKey"] = Config.get_options("auth", "accesskey")
#     # 系统当前日期
#     request_param["Timestamp"] = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
#     return request_param

#获取7.2的公共参数
# def generator_common_param_72(request_param):
#     if not request_param:
#         request_param = {}
#     # 数据中心编号
#     request_param["Region"] = Config.get_options("api", "beijing_region")
#     # AK
#     request_param["AccessKey"] = Config.get_options("authbak", "accesskey_bak")
#     # 系统当前日期
#     request_param["Timestamp"] = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
#     return request_param

# 获取公共参数_不录入ak
# def generator_common_param_ak(request_param):
#     if not request_param:
#         request_param = {}
#     # 数据中心编号
#     request_param["Region"] = Config.get_options("api", "default_regin")
#     # 系统当前日期
#     request_param["Timestamp"] = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
#     return request_param


# 获取公共参数
def generator_common_paramTwo(request_param,accesskey,region,timestamp=None):
    if not request_param:
        request_param = {}

    # 如果录入的ak为none就是不设置ak,如果ak为空则获取原始值，如果ak不为空则获取录入的值
    if accesskey == "":
        request_param["AccessKey"] = Config.get_options("auth", "accesskey")
    elif accesskey:
        request_param["AccessKey"] = accesskey
    # 数据中心编号 为空则获取默认值，否则获取录入的值
    if region == "":
        request_param["Region"] = Config.get_options("api", "default_regin")
    else:
        request_param["Region"] = region
    # 系统当前日期,为空则获取默认值，否则获取录入的值
    if timestamp == "":
        request_param["Timestamp"] = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    elif timestamp:
        request_param["Timestamp"] = timestamp
    return request_param




"""def request(param):
    r = None
    try:
        # 请求头
        headers = {'Content-Type': 'text/json; charset=utf-8',
                   'User-Agent': 'api-test'}
        # 发送post请求
        r = requests.post('http://%s/%s' % (Config.get_options("api","server") ,Config.get_options("api", "version")), data=json.dumps(param), headers=headers)
        result = {}
        if r.status_code == 200:
            result["data"] = r.json()
            print result["data"]
        # 给返回结果赋值
        result["status_code"] = r.status_code
    finally:
        if r:
            r.close()
    return result
"""
# 请求链接错误
# def request_error(param):
#     r = None
#     try:
#         # 请求头
#         headers = {'Content-Type': 'text/json; charset=utf-8',
#                    'User-Agent': 'api-test'}
#         # 发送post请求
#         r = requests.post('http://%s/%s' % (Config.get_options("api","server") ,Config.get_options("api", "version_error")), data=json.dumps(param), headers=headers)
#         result = {}
#         if r.status_code == 200:
#             result["data"] = r.json()
#             print result["data"]
#         # 给返回结果赋值
#         result["status_code"] = r.status_code
#     finally:
#         if r:
#             r.close()
#     return result

# post请求
def request_post(param,headers,code):
    r = None
    if headers == "":
        headers = {}
    else:
        headers = {'Content-Type': 'text/json; charset=utf-8',
                   'User-Agent': 'api-test'}
    try:
        # 发送post请求
        r = requests.post('http://%s/%s' % (Config.get_options("api","server") ,Config.get_options("api", "version")), data=json.dumps(param), headers=headers)
        result = {}
        if r.status_code == 200:
            result["data"] = r.json()
            print result["data"]
        # 判断返回的代码和预期的代码是否一致
        if result["data"]["Code"] == code:
            print "run ok!"
        # 给返回结果赋值
        result["status_code"] = r.status_code
    finally:
        if r:
            r.close()
    return result

# get请求参数
def request_get(param):
    r = None
    try:
        # 请求头
        headers = {'Content-Type': 'text/json; charset=utf-8',
                   'User-Agent': 'api-test'}
        # 发送post请求
        r = requests.get('http://%s/%s' % (Config.get_options("api","server") ,Config.get_options("api", "version")) , data=json.dumps(param), headers=headers)
        result = {}
        if r.status_code == 200:
            result["data"] = r.json()
            print result["data"]
        # 给返回结果赋值
        result["status_code"] = r.status_code
    finally:
        if r:
            r.close()
    return result

# 创建云主机的所有参数
def generator_compute(param):
    if not param:
        param = {}
    param["Action"] = "CreateInstance"
    param["VPCId"] = Config.get_options("compute", "default_vpcid")
    param["MsubNetId"] = Config.get_options("compute", "default_msub_netid")
    param["ImageId"] = Config.get_options("compute", "default_image_id")
    param["CPU"] = Config.get_options("compute", "default_cpu_count")
    param["Memory"] = Config.get_options("compute", "default_mem_size")
    param["LoginMode"] = Config.get_options("compute", "default_login_mode")
    param["Password"] = Config.get_options("compute", "default_password")
    param["InstanceName"] = Config.get_options("compute", "default_instance_name")
    param["PayType"] = Config.get_options("compute", "default_pay_type")
    return param

# 将当前的时间转化成为UTC的格式
def local_to_utc(local_ts, utc_format='%Y-%m-%dT%H:%M:%SZ'):
    local_tz = pytz.timezone('Asia/Shanghai')
    local_format = "%Y-%m-%d %H:%M:%S"
    time_str = time.strftime(local_format, time.localtime(local_ts))
    dt = datetime.datetime.strptime(time_str, local_format)
    local_dt = local_tz.localize(dt, is_dst=None)
    utc_dt = local_dt.astimezone(pytz.utc)
    return utc_dt.strftime(utc_format)

# 将为None或者为空的对象转化为空
def none_and_null(param):
    if(hasattr(param, ',')):
        print 'ok&&&&&&&&&&&&&&&&'
    if ("null" == param or None == param):
        param = ''
    return param

# 数组中过滤掉为空的值
def array_filter_null(param):
    jobs_list = []
    for value in param:
        if 'None' == value:
            jobs_list.append(None)
        else:
            jobs_list.append(value)
    return jobs_list