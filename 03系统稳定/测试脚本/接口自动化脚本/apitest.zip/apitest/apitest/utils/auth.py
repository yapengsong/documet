#! usr/bin/python #coding=utf-8
import hashlib
import hmac
import urllib
import json

import config

# def generator_signature(request_param):
#     secret_key_value = config.Config.get_options("auth", "secretkey")
#     if not secret_key_value:
#         raise Exception("请填写secretkey")
#     sort_tmp_param = {}
#     for key in request_param.keys():
#         if not isinstance(request_param[key], str):
#             sort_tmp_param[key] = json.dumps(request_param[key])
#         else:
#             sort_tmp_param[key] = request_param[key]
#     sort_param = [(k, sort_tmp_param[k]) for k in sorted(sort_tmp_param.keys())]
#     encode_data = urllib.urlencode(sort_param).replace('+', '')
#     return hmac.new(secret_key_value, encode_data, hashlib.sha1).digest().encode('base64').rstrip()

#数据中心的获取signature的方法,
def generator_signatureTwo(request_param,secretkey):
    #如果sk为空则获取初始值，如果sk为None为不设置，如果有值获取传递的值
    if secretkey == "":#sk为初始值
        secret_key_value = config.Config.get_options("auth", "secretkey")
    elif secretkey:#sk为录入的值
        secret_key_value = secretkey
    elif secretkey == "no":#sk为空
        secret_key_value = config.Config.get_options("authbak", "secretkey")
    # if not secret_key_value:
    #     raise Exception("请填写secretkey")
    sort_tmp_param = {}
    for key in request_param.keys():
        if not isinstance(request_param[key], str):
            sort_tmp_param[key] = json.dumps(request_param[key])
        else:
            sort_tmp_param[key] = request_param[key]
    sort_param = [(k, sort_tmp_param[k]) for k in sorted(sort_tmp_param.keys())]
    encode_data = urllib.urlencode(sort_param).replace('+', '')
    return hmac.new(secret_key_value, encode_data, hashlib.sha1).digest().encode('base64').rstrip()

# 录入的参数sk为空的方法
# def generator_signature_sk(request_param):
#     secret_key_value = config.Config.get_options("authbak", "secretkey")  # 获取sk的内容
#     if not secret_key_value:
#         raise Exception("请填写secretkey")
#     sort_param = [(k,request_param[k]) for k in sorted(request_param.keys())]
#     encode_data = urllib.urlencode(sort_param)
#     return hmac.new(secret_key_value, encode_data, hashlib.sha1).digest().encode('base64').rstrip()
