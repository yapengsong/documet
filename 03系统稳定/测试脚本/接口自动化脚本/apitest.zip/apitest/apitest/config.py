#! usr/bin/python #coding=utf-8
import ConfigParser
import os
#返回path的目录。其实就是os.path.split(path)的第一个元素
current_dir = os.path.dirname(__file__)

#class定义的内部类，其他类不能直接访问
class Config(object):
    options = {}

    # 构造函数
    def __init__(self):
        pass

    @classmethod
    # 字典里面的section里把值赋给param参数， def是函数定义
    def get_options(cls, section, option, default=None):
        value = None
        if section in Config.options:
            section_dict = Config.options[section]
            if option in section_dict:
                value = Config.options[section][option]
        if not value:
            value = default
        return value

    @classmethod
    # 把.ini里面的值赋值给参数
    def init_config(cls):
        cf = ConfigParser.ConfigParser()
        # 读取配置文件中的数据
        cf.read(os.path.join(current_dir, 'config.ini'))
        for section in cf.sections():
            for option in cf.options(section):
                option_dict = None
                value = cf.get(section, option)
                if section in Config.options:
                    option_dict = Config.options.get(section)
                if not option_dict:
                    option_dict = {option: value}
                else:
                    option_dict[option] = value
                Config.options[section] = option_dict



