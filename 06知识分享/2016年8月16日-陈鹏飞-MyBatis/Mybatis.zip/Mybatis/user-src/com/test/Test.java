package com.test;

import java.io.Reader;
import java.util.List;
import java.util.UUID;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.inter.UserInter;
import com.model.Article;
import com.model.User;

public class Test {
	private static SqlSessionFactory sqlSessionFactory;
	private static Reader reader;
	private static ApplicationContext ctx;
	static {
		ctx = new ClassPathXmlApplicationContext(
				"config/applicationContext.xml");
	}

	static {
		try {
			// 读取配置文件
			reader = Resources.getResourceAsReader("config/Configuration.xml");
			// 封装成session
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static SqlSessionFactory getSession() {
		return sqlSessionFactory;
	}

	public static void main(String[] args) {
		SqlSession session = sqlSessionFactory.openSession();
		try {
			// 执行已经映射的sql语句
			// User user = (User)
			// session.selectOne("com.model.UserMapper.selectUserById", "1");
			// 接口实现
			UserInter userInter = session.getMapper(UserInter.class);
			// 查询指定用户
			/*
			 * User user = userInter.findUserById("1");
			 * System.out.println(user.getUserAddress());
			 * System.out.println(user.getUserName());
			 */
			// 根据名称模糊查询
			/*
			 * List<User> userList = userInter.getUserListByName("%c%");
			 * System.out.println(userList.size()); for (User user : userList) {
			 * System.out.println("name:"+user.getUserName()); }
			 */
			// 创建
			/*
			 * User user = new User(); user.setId(UUID.randomUUID().toString());
			 * user.setUserName("wy"); user.setUserAge("99");
			 * user.setUserAddress("山西运城"); userInter.addUser(user);
			 * session.commit(); System.out.println(user.getId());
			 */
			// 修改
			/*
			 * User user = new User();
			 * user.setId("ccae2c09-6d76-42a3-a5a8-9af3fcb1f9c8");
			 * user.setUserAddress("shanxi,yuncheng");
			 * userInter.updateUser(user); session.commit();
			 */
			// 删除
			/*
			 * userInter.deleteUser("ccae2c09-6d76-42a3-a5a8-9af3fcb1f9c8");
			 * session.commit();
			 */
			// 级联查询
			/*List<Article> articleList = userInter.getUserArticles("1");
			System.out.println(articleList.size());
			for (Article article : articleList) {
				System.out.println(article.getTitle() + "的作者是:"
						+ article.getUser().getUserName());
			}*/
			// 测试id=1的用户查询，根据数据库中的情况，可以改成你自己的.
			System.out.println("得到用户id=1的用户信息");
			User user = userInter.findUserById("1");
			System.out.println(user.getUserAddress());
			// 得到文章列表测试
			System.out.println("得到用户id为1的所有文章列表");
			List<Article> articles = userInter.getUserArticles("1");
			for (Article article : articles) {
				System.out
						.println(article.getContent() + "--" + article.getTitle());
			}
		} finally {
			session.close();
		}
	}
}
