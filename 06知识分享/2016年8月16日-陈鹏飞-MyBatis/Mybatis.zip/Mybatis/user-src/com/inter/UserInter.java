package com.inter;

import java.util.List;

import com.model.Article;
import com.model.User;

public interface UserInter {
	public User findUserById(String id);
	public List<User> getUserListByName(String userName);
	public void addUser(User user);
	public void updateUser(User user);
	public void deleteUser(String id);
	public List<Article> getUserArticles(String id);
	
}
